/*Escribe un programa que lea líneas hasta que se introduzca en una de ellas la cadena
 "fin" sin importar si se hace en mayúsculas o en minúsculas o en cualquier
 combinación de ambas. Por cada línea leída,excepto la última, mostrará cuál es el
 primer carácter que no se repite.*/
package cadenaDeCaracteres;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Ej3 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String linea;
        do {
            System.out.print("Ingrese una linea ('fin' para terminar): ");
            linea = scanner.nextLine().toLowerCase();
            if (!linea.equals("fin")) {
                char primerNoRepetido = encontrarNoRepetido(linea);
                System.out.println("El primer caracter que no se repite: " + primerNoRepetido);
            }
        } while (!linea.equals("fin"));
        scanner.close();
	}
	private static char encontrarNoRepetido(String linea) {
        Map<Character, Integer> frecuenciaCaracteres = new HashMap<>();
        for (char c : linea.toCharArray()) {
            if (Character.isLetter(c)) {
                c = Character.toLowerCase(c); 
                frecuenciaCaracteres.put(c, frecuenciaCaracteres.getOrDefault(c, 0) + 1);
            }
        }
        for (char c : linea.toCharArray()) {
            if (Character.isLetter(c) && frecuenciaCaracteres.get(Character.toLowerCase(c)) == 1) {
                return c;
            }
        }
        return ' ';
	}

}
