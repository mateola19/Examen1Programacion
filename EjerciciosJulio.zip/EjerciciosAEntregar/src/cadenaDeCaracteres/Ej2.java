/*Escribe un programa que lea dos cadenas y muestre el número de veces que encuentra
  cada palabra de la primera dentro de la segunda.*/

package cadenaDeCaracteres;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Ej2 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese una cadena de caracteres: ");
        String cadena1 = sc.nextLine();
        System.out.print("Ingrese otra cadena de caracteres: ");
        String cadena2 = sc.nextLine();
        Map<String, Integer> contadorPalabras = contarPalabras(cadena1, cadena2);
        System.out.println("Numero de veces que cada palabra se encuentra en la segunda cadena: ");
        for (Map.Entry<String, Integer> entry : contadorPalabras.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue() + " veces");
        }
        sc.close();
	}
	private static Map<String, Integer> contarPalabras(String cadena1, String cadena2) {
        Map<String, Integer> contadorPalabras = new HashMap<>();
        String[] palabras = cadena1.split("\\s+");
        for (String palabra : palabras) {
            int contador = contarCadena2(cadena2, palabra);
            contadorPalabras.put(palabra, contador);
            
        }
        return contadorPalabras;
	}
	private static int contarCadena2(String cadena1, String cadena2) {
        int contador = 0;
        int index = cadena1.indexOf(cadena2);while (index != -1) {
            contador++;
            index = cadena1.indexOf(cadena2, index + 1);
        }
        return contador;
        
	}
        
}
