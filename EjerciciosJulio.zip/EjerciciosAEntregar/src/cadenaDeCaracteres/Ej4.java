/*Escribe un programa que lea nombres y construya un triángulo con sus caracteres tal y
  como se muestra en el ejemplo siguiente: El programa finalizará cuando lea la palabra
  “fin”.
*/
package cadenaDeCaracteres;

import java.util.Scanner;

public class Ej4 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String nombre;
        do {
            System.out.print("Ingrese un nombre ('fin' para terminar): ");
            nombre = scanner.nextLine().toLowerCase();
            if (!nombre.equals("fin")) {
                dibujarTriangulo(nombre);
            }
        } while (!nombre.equals("fin"));
        scanner.close();
	}
	private static void dibujarTriangulo(String nombre) {
		System.out.println("Nombre: " + nombre);
		for (int i = 1; i <= nombre.length(); i++) {
			String textoMostrar = nombre.substring(0, i);
			System.out.println(textoMostrar);
			
		}
	}

}
