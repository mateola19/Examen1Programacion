/*Escribe un programa que lea nombres y muestre el resultado de sustituir los caracteres
  centrales (todos menos el primero y el último) por asteriscos. Se ha de tener en
  cuenta que cada nombre puede estar precedido y/o seguido de un número arbitrario de
  espacios en blanco y que, de ser así, estos no aparecerán en el resultado.Resolver
  este ejercicio sin usar sentencias repetitivas.*/
package cadenaDeCaracteres;

import java.util.Scanner;

public class Ej5 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca un nombre: ");
        String nombre = sc.next().trim();
        if (nombre.length() >= 3) {
        	String caracteresCentrales = nombre.substring(1, nombre.length() - 1);
        	String resultado = nombre.charAt(0) 
        			+ caracteresCentrales.replaceAll(".", "*") + 
        			nombre.charAt(nombre.length() - 1);
        	System.out.println(resultado);
        }
        else {
        	System.out.println("El nombre tiene que tener mas de 3 caracteres");
        }
	}

}
