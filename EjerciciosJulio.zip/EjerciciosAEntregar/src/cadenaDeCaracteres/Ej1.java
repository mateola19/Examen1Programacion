/*Escribe un programa que lea dos cadenas y muestre el número de veces que la segunda
  está contenida en la primera.*/

package cadenaDeCaracteres;

import java.util.Scanner;

public class Ej1 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese una cadena de caracteres: ");
        String cadena1 = sc.nextLine();
        System.out.print("Ingrese otra cadena de caracteres: ");
        String cadena2 = sc.nextLine();
        int contador = contarCadenas(cadena1, cadena2);
        System.out.println("La segunda cadena esta contenida en la primera " + contador + " veces");
        sc.close();
        
	}
	
	private static int contarCadenas(String cadena1, String cadena2) {
        int contador = 0;
        int index = cadena1.indexOf(cadena2);
        while (index != -1) {
            contador++;
            index = cadena1.indexOf(cadena2, index + 1);
            
        }
        return contador;
        
	}
	
}
