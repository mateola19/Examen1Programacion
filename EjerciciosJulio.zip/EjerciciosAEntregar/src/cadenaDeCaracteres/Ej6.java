/*Escribe un programa que lea secuencias de caracteres con el formato siguiente:
  LetraNúmeroCarácter. Por ejemplo, las siguientes son cadenas de este tipo: M135t,
  b57X, n1335$ o L91. La entrada puede constar de varias líneas y cada una puede
   contener cero o más secuencias.Cada secuencia se procesará para generar un valor
    numérico de la forma siguiente:
• Si la primera letra es mayúscula, el número que hay entre ella el último carácter se
 multiplicará por el valor numérico de dicha letra. En caso contrario, en lugar de la
  multiplicación se realizará una división.
• Si el último carácter es alfabético, se calculará la raíz cuadrada del resultado
 anterior. Si es un dígito, se calculará su logaritmo neperiano. En caso contrario se 
 calculará el resultado de elevar el número de Euler a dicho resultado.
El programa finalizará, mostrando la suma de todos los valores numéricos obtenidos de 
cada secuencia,cuando se detecte en la entrada un EOF.
Se asume que no se cometen errores en la entrada de datos y todas las secuencias son 
válidas.*/
package cadenaDeCaracteres;

import java.util.Scanner;

public class Ej6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca un secuencia de caracteres"
                + "(de formato LetraNumeroCaracter): ");

        String lineaLeida = "";
        char letra;
        String cadenaInterna = "";
        double numeros = 0.0;
        double resultado = 0;
        char ultimo;
        double resultadoFinal = 0;
        String secuenciaAProcesar = "";

        while(sc.hasNextLine()) {
            //trim = quita espacios al principio y al final
            lineaLeida = sc.nextLine().trim();
            //Si la línea no es vacía
            if(!lineaLeida.isEmpty()) {
                //Hacemos un split a lineaLeida para ver si existe más de una secuencia en la misma línea
                String[] secuencia = lineaLeida.split(" ");

                for (int i = 0; i <= secuencia.length - 1; i++) {

                    secuenciaAProcesar = secuencia[i];
                    //System.out.println("Secuencia a procesar: " + secuenciaAProcesar);
                    letra = secuenciaAProcesar.charAt(0);
                    //System.out.println("Letra obtenida: " + letra);
                    cadenaInterna = secuenciaAProcesar.substring(1, secuenciaAProcesar.length() - 1);
                    //System.out.println("Cadena Interna: " + cadenaInterna);
                    numeros = Integer.parseInt(cadenaInterna);
                    ultimo = secuenciaAProcesar.charAt(secuenciaAProcesar.length() - 1);

                    //isUppercase devuelve true si el caracter es mayuscula
                    if (Character.isUpperCase(letra)) {
                        resultado = numeros * ((int)letra);
                    }
                    else {
                        resultado = numeros / ((int)letra);
                    }
                    //isAlphabetic devuelve true si el caracter es alfabético
                    if(Character.isAlphabetic(ultimo)){
                        //raiz cuadrada
                        resultado = Math.sqrt(resultado);
                    }
                    //isDigit devuelve true si el caracter es
                    else if(Character.isDigit(ultimo)) {
                        //logaritmo neperiano
                        resultado = Math.log(resultado);
                    }
                    //Euler
                    else {
                        resultado = Math.exp(resultado);
                    }

                    //System.out.println("Resultado de la secuencia: " + resultado);
                    //Acunulamos el resultado de la secuencia en el contador total
                    resultadoFinal += resultado;
                }
            }
        }

        System.out.println("Resultado total de todas las secuencias: " + resultadoFinal);
    }

}
