package arrays;

import java.util.Random;

public class Ej10 {
	public static void main(String[] args) {
		int [][] m = matrizAleatoria();
		System.out.println("La matriz generada es: ");
		imprimir(m);
	}
	public static int[][] matrizAleatoria() {
		Random r = new Random();
		int filas = r.nextInt(19) + 2;
		int columnas = r.nextInt(19) + 2;
		int [][]matriz = new int [filas][columnas];
		 for (int i = 0; i < filas; i++) {
	            for (int j = 0; j < columnas; j++) {
	                matriz[i][j] = r.nextInt(100);
	          }
		 }
	return matriz;
	}
	public static void imprimir(int[][] m) {
		int sumaFilas = 0;
		int [] sumaColumnas = new int [m[0].length];
		for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
            	sumaFilas += m[i][j];
            	sumaColumnas[j] += m[i][j];
            	System.out.print(m[i][j] + " ");
            }
            System.out.println("--> " + sumaFilas);
            sumaFilas = 0;
        }
		for (int n = 0; n < sumaColumnas.length; n++) {
			System.out.print(sumaColumnas[n] + " ");
		}
		
	
	}

}
