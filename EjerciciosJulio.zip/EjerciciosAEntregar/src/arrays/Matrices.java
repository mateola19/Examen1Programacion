package arrays;

public class Matrices {
	public static int [][] cuadrada1(int dim){
		int [][] matrizCuadrada = new int[dim][dim];
		for(int i = 0; i < dim; i++) {
			for(int j = 0; j < dim; j++) {
				matrizCuadrada[i][j] = (i + 1) + (j * dim);
			}
		}
		return matrizCuadrada;
		
	}
	public static int [][] cuadrada2(int dim){
		int [][] matrizCuadrada = new int[dim][dim];
		for(int i = 0; i < dim; i++) {
			for(int j = 0; j < dim; j++) {
				if(j%2 == 0) {
					matrizCuadrada[i][j] = (i + 1) + (j * dim);
				}
				else {
					matrizCuadrada[i][j] = (j * dim) + (dim - i);
				}
				
				
			}
		}
		return matrizCuadrada;
		
	}
	public static String [][] palindromos(int f, int c){
		String abecedario = "abcdefghijklmnñopqrstuvwxyz";
		if( c >= 1 && c <= 26 && f >= 1 && f <= 26 ) {
			String [][] mPalindromo = new String[f][c];
			for(int i = 0; i < f; i++) {
				for(int j = 0; j < c; j++) {
					String palindromo = "" + abecedario.charAt(i) + 
							abecedario.charAt((i + j)% abecedario.length())
					+ abecedario.charAt(i);
					mPalindromo [i][j] = palindromo;
				}
			}
			return mPalindromo;
		}
		else {
			return null;
		}
	}
	public static int max3x3sum(int [][] matriz) {
		int maxSum = 0;
		int filas = matriz.length;
		int columnas = matriz[0].length;
		for(int i = 0; i < filas; i++) {
			for(int j = 0; j < columnas; j++) {
				int suma = 0;
				for(int x = i; x < i + 3; x++) {
					for(int y = j; y < j + 3; y++) {
						if(x < filas && y < columnas) {
							suma += matriz[x][y];
						}
					}
				}
				maxSum = Math.max(maxSum, suma);
			}
		}
		
		
		return maxSum;
	}
	public static int [][] rellenarMatriz(int filas, int columnas){
		int[][] matriz = new int [filas][columnas];
		for(int i = 0; i < filas; i++) {
			for(int j = 0; j < columnas; j++) {
				matriz[i][j] = (int) (Math.random() * 11);
			}
		}
		return matriz;
	}
	public static void mostrarMatriz (int [][] matriz) {
		for(int i = 0; i < matriz.length; i++) {
			for(int j = 0; j < matriz[i].length; j++) {
				System.out.print(matriz[i][j] + "\t");
			}
			System.out.println("");
		}
	}
	public static void mostrarMatriz (String [][] matriz) {
		for(int i = 0; i < matriz.length; i++) {
			for(int j = 0; j < matriz[i].length; j++) {
				System.out.print(matriz[i][j] + "\t");
			}
			System.out.println("");
		}
	}

}
