package arrays;

import java.util.Scanner;

public class Ej16 {
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Ingrese el número de filas: ");
	        int filas = sc.nextInt();
	        System.out.print("Ingrese el número de columnas: ");
	        int columnas = sc.nextInt();
	        char[][] matriz = new char[filas][columnas];
	        System.out.println("Ingrese una matriz de caracteres:");
	        for (int i = 0; i < filas; i++) {
	            String f = sc.next();
	            matriz[i] = f.toCharArray();
	            
	        }
	        System.out.print("Ingrese el carácter de relleno: ");
            char caracter = sc.next().charAt(0);
            System.out.print("Ingrese la primera fila: ");
            int fila1 = sc.nextInt();
            System.out.print("Ingrese la primera columna: ");
            int columna1 = sc.nextInt();
            System.out.println("la matriz original:");
            mostrar(matriz);
            rellenar(matriz, fila1, columna1, matriz[fila1][columna1], caracter);
            System.out.println("Matriz despues del relleno:");
            mostrar(matriz);
            sc.close();
	 }
	 private static void mostrar(char[][] matriz) {
	        for (char[] fila : matriz) {
	            for (char c : fila) {
	                System.out.print(c + " ");
	            }
	            System.out.println();
	        }
	    }
	 private static void rellenar(char[][] matriz, int filaInicial, int columnaInicial,
			 char caracterInicial, char caracterRelleno) {
		 if (filaInicial < 0 || filaInicial >= matriz.length || columnaInicial < 0 ||
				 columnaInicial >= matriz[0].length) {
	            return;
	        }
		 if (matriz[filaInicial][columnaInicial] == caracterInicial) {
			 matriz[filaInicial][columnaInicial] = caracterRelleno;
			// Arriba
			 	rellenar(matriz, filaInicial - 1, columnaInicial, caracterInicial, caracterRelleno); 
			 // Abajo
	            rellenar(matriz, filaInicial + 1, columnaInicial, caracterInicial, caracterRelleno); 
	         // Izquierda
	            rellenar(matriz, filaInicial, columnaInicial - 1, caracterInicial, caracterRelleno); 
	         // Derecha
	            rellenar(matriz, filaInicial, columnaInicial + 1, caracterInicial, caracterRelleno); 
		 }

	 }
}
