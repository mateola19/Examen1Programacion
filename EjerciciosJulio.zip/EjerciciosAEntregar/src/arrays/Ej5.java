package arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Ej5 {
	public static int maximo(int[] vector) {
		int[] vectorCopia = vector.clone();
		Arrays.sort(vectorCopia);
		return vectorCopia[vectorCopia.length - 1];
	}
	public static double media(int[] vector) {
		int suma = 0;
		for (int n: vector) {
			suma += n;
		}
		return suma/vector.length;
	}
	public static int cadenas(String[] vector, String s) {
		int i = 0;
		for (String string : vector) {
			if(string.contains(s)) {
				i++;
			}
		}
		return i;
	}
	public static boolean comparacion(String[] vector1, String[] vector2) {
		return Arrays.equals(vector1, vector2);
	}
	public static void intercambiar(String[] vector) {
		for(int i = 0; i < vector.length - 1; i+= 2) {
			String s = vector[i];
			vector[i] = vector[i + 1];
			vector[i + 1] = s;
		}
		
	}
	public static void mostrarVector(String[] vector) {
		for(int i = 0; i < vector.length; i++) {
			System.out.print(vector[i] + ", ");
		}
		System.out.println();
	}
	public static int rango(int[] vector) {
		int[] vectorCopia = vector.clone();
		Arrays.sort(vectorCopia);
		return vectorCopia[vectorCopia.length - 1] - vectorCopia[0] + 1;
	}
	public static double raizCuadrada (int[] vector) {
		double media = media(vector);
		double numerador = 0.0;
		for (int n: vector) {
			numerador += n - media;
		}
		double denominador = vector.length - 1;
		double desviacionEstandart = Math.sqrt(numerador/denominador);
		return desviacionEstandart;
	}
	public static int minDif (int [] vector) {
		 int minDif = Integer.MAX_VALUE;
	        for (int i = 1; i < vector.length; i++) {
	            int diferencia = Math.abs(vector[i] - vector[i - 1]);
	            minDif = Math.min(minDif, diferencia);
	        }

	        return minDif;
	    }
	public static int[] sumarPares(int[] vector) {
		 int[] resultado = new int[(int) Math.ceil(vector.length / 2.0)];
	        for (int i = 0; i < vector.length; i += 2) {
	            if (i + 1 < vector.length) {
	                resultado[i / 2] = vector[i] + vector[i + 1];
	            } else {
	                resultado[i / 2] = vector[i];
	            }
	        }

	        return resultado;
	    }
	public static void mostrarVector2(int[] vector) {
		for(int i = 0; i < vector.length; i++) {
			System.out.print(vector[i] + ", ");
		}
		System.out.println();
	}
	public static int[] concatenarVectores(int[] vector1, int[] vector2) {
        int[] resultado = new int[vector1.length + vector2.length];
        System.arraycopy(vector1, 0, resultado, 0, vector1.length);
        System.arraycopy(vector2, 0, resultado, vector1.length, vector2.length);
        return resultado;
    }
	 public static int longitud(int[] vector) {
		 int maxLength = 1;
	     int Length = 1;
	     for (int i = 1; i < vector.length; i++) {
	            if (vector[i] > vector[i - 1]) {
	                Length++;
	            } else {
	                maxLength = Math.max(maxLength, Length);
	                Length = 1;
	            }
	        }

	        return Math.max(maxLength, Length);
	    }   
	 }

	
	
	

