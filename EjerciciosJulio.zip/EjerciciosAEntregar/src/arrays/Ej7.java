package arrays;

import java.util.Random;
import java.util.Scanner;

public class Ej7 {
	 public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
		 System.out.println("Ingrese un tamaño entre 10 y 20: ");
		 int tamaño = scanner.nextInt();
		 while (tamaño < 10 || tamaño > 20) {
			 System.out.println("El tamaño del vector es invalido, por favor introduzca uno nuevo: ");
			 tamaño = scanner.nextInt();
			 
		 }
		 int [] vector = new int[tamaño];
		 llenarVector(vector);
		 System.out.println("El contenido del vector es: ");
		 mostrarVector(vector);
		 int minDif = calcularMinDif(vector);
		 System.out.println("La minima diferencia entre dos valores adyacentes es: " + minDif);
    }
	 private static void llenarVector(int[] vector) {
		 //Random rn = new Random();
		 int min = 10;
		 int max = 40 - min;
		 for (int i = 0; i < vector.length; i++) {
			 vector[i] = (int)((Math.random() * max) + min);
			 //vector[i] = rn.nextInt(100);
		 }
	 }
	 private static void mostrarVector(int[] vector) {
		 for (int i = 0; i < vector.length; i++) {
			 System.out.print(vector[i] + ", ");
			 
		 }
		 System.out.println();
	 }
	 private static int calcularMinDif (int[] vector) {
		 int minDif = Integer.MAX_VALUE;
		 for (int i = 1; i < vector.length; i++) {
			 int dif = vector[i] - vector[i - 1];
	            if (dif < minDif) {
	                minDif = dif;
	            }
		 }
		 return minDif;
	 }

}
