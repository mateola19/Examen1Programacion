package arrays;

public class PruebaEj5 {
	public static void main(String[] args) {
		int [] vector = {4, 7, 8, 6, 4, 35, 13, 55};	
		int maximo = Ej5.maximo(vector);
		
		System.out.println("El maximo del vector es: " + maximo);
		
		double media = Ej5.media(vector);
		System.out.println("La media del vector es: " + media);
		
		String s = "piña";
		String[] vectorCadenas = {"Frutas", "piña", "manzana", "pera"};
		int cadenas = Ej5.cadenas(vectorCadenas, s);
		System.out.println("Cuantas vececes se repite " + s + " en el vector: " + cadenas);
		
		String[] vector1 = {""};
		String[] vector2 = {""};
		boolean comparacion = Ej5.comparacion(vector1, vector2);
		System.out.println(comparacion);
		
		Ej5.intercambiar(vectorCadenas);
		Ej5.mostrarVector(vectorCadenas);
		
		int rango = Ej5.rango(vector);
		System.out.println("El rango del vector es: " + rango);
		
		double raizCuadrada = Ej5.raizCuadrada(vector);
		System.out.println("La desviacion estandart del vector es: " + raizCuadrada);
		
		int minDif = Ej5.minDif(vector);
		System.out.println("La minima diferencia del vector es: " + minDif);
		
		int[] sumarPares = Ej5.sumarPares(vector);
		Ej5.mostrarVector2(sumarPares);
		
		int[] vector4 = {44, 78, 99, 63, 21, 4};
		int[] concatenarVectores = Ej5.concatenarVectores(vector, vector4);
		Ej5.mostrarVector2(concatenarVectores);
		
		int longitud = Ej5.longitud(vector);
		System.out.println(longitud);
	}

}
