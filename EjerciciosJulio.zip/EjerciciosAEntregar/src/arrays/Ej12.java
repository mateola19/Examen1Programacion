package arrays;

import java.util.Scanner;

public class Ej12 {
	
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese un numero de alumnos: ");
		int numAl = sc.nextInt();
		sc.nextLine();
		Alumno[] alumnos = new Alumno[numAl];
		for (int i = 0; i < numAl; i++) {
            System.out.print("Ingrese el nombre del alumno " + (i + 1) + ": ");
            Alumno alumno = new Alumno();
            alumno.setNombre(sc.nextLine());
            System.out.println("Introduzca las notas de la primera evaluacion: ");
            double [] notas = new double [3];
            for (int j = 0; j < 3; j++) {
            	notas [j] = sc.nextDouble();
            }
            alumno.setNotas1(notas);
            
            System.out.println("Introduzca las notas de la segunda evaluacion: ");
            notas = new double [3];
            for (int j = 0; j < 3; j++) {
            	notas [j] = sc.nextDouble();
            }
            alumno.setNotas2(notas);
            
            System.out.println("Introduzca las notas de la tercera evaluacion: ");
            notas = new double [3];
            for (int j = 0; j < 3; j++) {
            	notas [j] = sc.nextDouble();
            }
            alumno.setNotas3(notas);
		}
		sc.nextLine();
	
	int opcion;
	do {
		System.out.println("\nMenú:");
        System.out.println("1. Mostrar la nota media de todos los alumnos.");
        System.out.println("2. Mostrar la nota media de un alumno determinado.");
        System.out.println("3. Visualizar las notas por evaluación y la nota final de cada evaluación.");
        System.out.println("4. Visualizar las notas por evaluación y la nota final de un alumno determinado.");
        System.out.println("5. Calcular la nota media del curso.");
        System.out.println("6. Calcular la nota más alta y la más baja e indicar a qué alumno y evaluación pertenece.");
        System.out.println("7. Salir.");
        System.out.println("Seleccione una opcion: ");
        opcion = sc.nextInt();
        switch (opcion) {
        case 1:
            mostrarNotaMedia(alumnos);
            break;
        case 2:
        	Alumno alumno = elegirAlumno(alumnos);
            mostrarNotaMediaAlumno(alumno);
            break;
        case 3:
            visualizarNotas(alumnos);
            break;
        case 4:
        	Alumno alumno2 = elegirAlumno(alumnos);
        	visualizarNotasAlumno(alumno2);
            break;
        case 5:
            Double notaMediaCurso = calcularMedia(alumnos);
            System.out.println("La nota media del curso es: " + notaMediaCurso);
            break;
        case 6:
            calcularNotaMasAltaYBaja(alumnos);
            break;
        case 7:
            System.out.println("¡Hasta luego!");
            break;
            default:
            	System.out.println("La opcion no es valida, intentelo de nuevo");
            	
        	}
		}while (opcion != 7);
	}
			
			private static void mostrarNotaMedia(Alumno[] alumnos) {
				double mediaIndividual = 0.0;
				
				for (int i = 0; i < alumnos.length; i++) {
					mediaIndividual += calcularMediaIndividual(alumnos[i]);
					
				}
				
				System.out.println("la nota media de todos los alumnos es: " + mediaIndividual/alumnos.length);
				
			}
			private static void mostrarNotaMediaAlumno(Alumno alumno) {
				double mediaAlumno;
				mediaAlumno = calcularMediaIndividual(alumno);
				System.out.println("La nota media del alumno " + alumno.getNombre() + " es: " + mediaAlumno);
			}	
			private static void visualizarNotas (Alumno[] alumnos) {
				for (int i = 0; i < alumnos.length; i++) {
					double notaMedia1Ev = 0.0;
					double notaMedia2Ev = 0.0;
					double notaMedia3Ev = 0.0;
					System.out.println("Notas de " + alumnos[i].getNombre());
					System.out.println(" --------------------------------------- ");
					System.out.println("Notas evaluacion 1");
					for(int j = 0; j < alumnos[i].getNotas1().length; j++) {
						System.out.print((alumnos[i].getNotas1()[j]) + " - ");
						notaMedia1Ev += (alumnos[i].getNotas1()[j]);
					}
					System.out.println("La nota final de la primera evaluacion es: " + notaMedia1Ev/alumnos[i].getNotas1().length);
					
					System.out.println(" --------------------------------------- ");
					System.out.println("Notas evaluacion 2");
					for(int j = 0; j < alumnos[i].getNotas2().length; j++) {
						System.out.print((alumnos[i].getNotas2()[j]) + " - ");
						notaMedia2Ev += (alumnos[i].getNotas2()[j]);
					}
					System.out.println("La nota final de la segunda evaluacion es: " + notaMedia2Ev/alumnos[i].getNotas2().length);
					System.out.println(" --------------------------------------- ");
					
					for(int j = 0; j < alumnos[i].getNotas3().length; j++) {
						System.out.print((alumnos[i].getNotas3()[j]) + " - ");
						notaMedia3Ev += (alumnos[i].getNotas3()[j]);
					}
					System.out.println("La nota final de la tercera evaluacion es: " + notaMedia3Ev/alumnos[i].getNotas3().length);
					System.out.println(" --------------------------------------- ");
				}
				
				
			}
			private static void visualizarNotasAlumno (Alumno alumno) {
				System.out.println("Notas evaluacion 1");
				for(int i = 0; i < alumno.getNotas1().length; i++) {
					System.out.print((alumno.getNotas1()[i]) + " - ");
				}
				System.out.println(" --------------------------------------- ");
				System.out.println("Notas evaluacion 2");
				for(int i = 0; i < alumno.getNotas2().length; i++) {
					System.out.print((alumno.getNotas2()[i]) + " - ");
				}
				System.out.println(" --------------------------------------- ");
				
				for(int i = 0; i < alumno.getNotas3().length; i++) {
					System.out.print((alumno.getNotas3()[i]) + " - ");
				}
				System.out.println(" --------------------------------------- ");
				double notaFinal = calcularMediaIndividual(alumno);
				System.out.println("La nota final de " + alumno.getNombre() + " es: " + notaFinal);
					
				
				
			}
			private static double calcularMedia (Alumno[] alumnos) {
				double notaMediaCurso = 0.0;
				for (int i = 0; i < alumnos.length; i++) {
					notaMediaCurso += calcularMediaIndividual(alumnos[i]);
				}
				return notaMediaCurso;
				
			}
			private static void calcularNotaMasAltaYBaja (Alumno[] alumnos) {
				double notaAlta = 0.0, notaBaja = 0.0;
				int numEv = 0, numEvBaja = 0;
				String nombreAlumno = "", nombreAlumnoBaja = "";
				for (int i = 0; i < alumnos.length; i++) {
					double[] notasAlumno1Ev = alumnos[i].getNotas1();
					for (int j = 0; j < notasAlumno1Ev.length; j++) {
						if (notasAlumno1Ev[j] > notaAlta) {
							notaAlta = notasAlumno1Ev[j];
							numEv = 1;
							nombreAlumno = alumnos[i].getNombre();
						}
						if (notasAlumno1Ev[j] < notaBaja) {
							notaBaja = notasAlumno1Ev[j];
							numEvBaja = 1;
							nombreAlumnoBaja = alumnos[i].getNombre();
						}
					}
					double[] notasAlumno2Ev = alumnos[i].getNotas2();
					for (int j = 0; j < notasAlumno2Ev.length; j++) {
						if (notasAlumno2Ev[j] > notaAlta) {
							notaAlta = notasAlumno2Ev[j];
							numEv = 2;
							nombreAlumno = alumnos[i].getNombre();
						}
						if (notasAlumno2Ev[j] < notaBaja) {
							notaBaja = notasAlumno2Ev[j];
							numEvBaja = 2;
							nombreAlumnoBaja = alumnos[i].getNombre();
						}
					}
					double[] notasAlumno3Ev = alumnos[i].getNotas3();
					for (int j = 0; j < notasAlumno3Ev.length; j++) {
						if (notasAlumno3Ev[j] > notaAlta) {
							notaAlta = notasAlumno3Ev[j];
							numEv = 3;
							nombreAlumno = alumnos[i].getNombre();
						}
						if (notasAlumno3Ev[j] < notaBaja) {
							notaBaja = notasAlumno3Ev[j];
							numEvBaja = 3;
							nombreAlumnoBaja = alumnos[i].getNombre();
						}
					}
				}
				System.out.println("La nota mas alta es: " + notaAlta + " del alumno " + nombreAlumno
						+ " en la evaliuacion " + numEv);
				System.out.println("La nota mas baja es: " + notaBaja + " del alumno " + nombreAlumnoBaja
						+ " en la evaliuacion " + numEvBaja);
			}
			private static double calcularMediaIndividual(Alumno alumno) {
				double notaMedia1Ev = 0.0;
				double notaMedia2Ev = 0.0;
				double notaMedia3Ev = 0.0;
				for(int i = 0; i < alumno.getNotas1().length; i++) {
					notaMedia1Ev += (alumno.getNotas1()[i]);
				}
				notaMedia1Ev = (notaMedia1Ev/alumno.getNotas1().length);
				
				for(int i = 0; i < alumno.getNotas2().length; i++) {
					notaMedia2Ev += (alumno.getNotas2()[i]);
				}
				notaMedia2Ev = (notaMedia2Ev/alumno.getNotas2().length);
				
				for(int i = 0; i < alumno.getNotas3().length; i++) {
					notaMedia3Ev += (alumno.getNotas3()[i]);
				}
				notaMedia3Ev = (notaMedia3Ev/alumno.getNotas3().length);
				
				double notaMediaTotal = ((notaMedia1Ev + notaMedia2Ev + notaMedia3Ev)/3);
				
				
				return notaMediaTotal;
			}
			private static Alumno elegirAlumno (Alumno [] alumnos) {
				Scanner sc = new Scanner(System.in);
				int indice = 0;
				System.out.println("Por favor elija a un alumno: ");
				for (int i = 0; i < alumnos.length; i++) {
					System.out.println((i + 1) + ".-" + alumnos[i].getNombre());
					
				}
				indice = sc.nextInt();
				while(indice < 1 || indice > alumnos.length){
					System.out.println("El alumno selecionado no existe");
					indice = sc.nextInt();
				}
				Alumno alumno =alumnos[indice - 1];
				return alumno;
			}
			
	

}
