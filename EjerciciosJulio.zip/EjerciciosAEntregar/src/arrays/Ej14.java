package arrays;

import java.util.Arrays;
import java.util.Random;

public class Ej14 {
	public static void main(String[] args) {
		int[] vector1 = generarVector();
        int[] vector2 = generarVector();
        System.out.println("Vector 1 : " + Arrays.toString(vector1));
        System.out.println("Vector 2 : " + Arrays.toString(vector2));
        Arrays.sort(vector1);
        Arrays.sort(vector2);
        int[] vectorMezcla = mezclar(vector1, vector2);
        System.out.println("Vector 1 : " + Arrays.toString(vector1));
        System.out.println("Vector 2 : " + Arrays.toString(vector2));
        System.out.println("Vector mezcla: " + Arrays.toString(vectorMezcla));
        
	}
	private static int[] generarVector() {
        Random rn = new Random();
        int longitud = rn.nextInt(91) + 10;
        int[] vector = new int[longitud];
        for (int i = 0; i < longitud; i++) {
            vector[i] = rn.nextInt(1000);
            
        }
        return vector;
	}
	private static int[] mezclar(int[] vector1, int[] vector2) {
        int[] resultado = new int[vector1.length + vector2.length];
        int i = 0, j = 0, k = 0;
        while (i < vector1.length && j < vector2.length) {
            if (vector1[i] < vector2[j]) {
                resultado[k++] = vector1[i++];
            }else {
            	resultado[k++] = vector2[j++];
            }
        }
        while (i < vector1.length) {
            resultado[k++] = vector1[i++];
        }
        while (j < vector2.length) {
            resultado[k++] = vector2[j++];
        }
        return resultado;
	}
        
}
