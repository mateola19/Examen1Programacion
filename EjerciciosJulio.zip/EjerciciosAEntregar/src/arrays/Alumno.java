package arrays;

/**
 * @author Usuario
 *
 */
public class Alumno {
	private String nombre;
	//nota 1 ev
	private double [] notas1;
	//nota 2 ev
	private double [] notas2;
	//nota 3 ev
	private double [] notas3;
	
	public Alumno() {
		super();
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double[] getNotas1() {
		return notas1;
	}
	public void setNotas1(double[] notas1) {
		this.notas1 = notas1;
	}
	public double[] getNotas2() {
		return notas2;
	}
	public void setNotas2(double[] notas2) {
		this.notas2 = notas2;
	}
	public double[] getNotas3() {
		return notas3;
	}
	public void setNotas3(double[] notas3) {
		this.notas3 = notas3;
	}
	
	

}
