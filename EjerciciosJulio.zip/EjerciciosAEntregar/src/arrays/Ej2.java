package arrays;

import java.util.Arrays;
import java.util.Random;

public class Ej2 {
	public static void main(String [] args) {
		int tamaño = new Random().nextInt(41) + 10;
		int[] vector1 = new int [tamaño];
		llenarVector(vector1);
		int[] vector2 = vectorInverso(vector1);
		System.out.println("Vector1: " + Arrays.toString(vector1));
        //System.out.println("Vector2 : " + Arrays.toString(vector2));
	}
	private static void llenarVector(int[] vector) {
		Random random = new Random();
        for (int i = 0; i < vector.length; i++) {
			int aleatorio = random.nextInt(201) - 100;
			if(existe(vector, aleatorio)) {
				//si existe se genera otro numero aleatorio
				aleatorio = random.nextInt(201) - 100;
			}
			vector[i] = aleatorio;
			
        }
	}
	private static boolean existe(int []vector, int numero) {
		for(int i = 0; i < vector.length; i++  ) {
			if (numero == vector[i]) {
				System.out.println("Este numero ya existe " + numero);
				return true;
			}
		}
		return false;
	}
	private static int[] vectorInverso(int[] vector1) {
		int [] vectorIn = new int[vector1.length];
		for (int i = vector1.length - 1; i >= 0; i--) {
			vectorIn[vectorIn.length - i] = vector1[i];
		}
		return vectorIn;
	}

}
