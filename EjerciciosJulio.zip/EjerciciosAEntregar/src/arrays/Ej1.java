package arrays;

import java.util.Scanner;
import java.util.Random;

public class Ej1 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Ingrese el numero de lanzamientos del dado (d): ");
	        int d = scanner.nextInt();
	        int[] contarCaras = new int[6];
	        Random random = new Random();
	        for (int i = 0; i < d; i++) {
	            int resultado = random.nextInt(6) + 1;
	            contarCaras[resultado - 1]++;
	        }
	        System.out.println("El resultado de los lanzamientos es: ");
	        for (int cara = 1; cara <= 6; cara++) {
	            System.out.println("Cara " + cara + ": " + contarCaras[cara - 1] + " veces");
	       
	        }
	        scanner.close();
	    }

}
