package arrays;

import java.util.Scanner;

public class PruebaMatrices {
	public static void main(String[] args) {
		int [][] matrizCuadrada = Matrices.cuadrada1(4);
		Matrices.mostrarMatriz(matrizCuadrada);
		int [][] matrizCuadrada2 = Matrices.cuadrada2(6);
		Matrices.mostrarMatriz(matrizCuadrada2);
		String [][] mPalindromos = Matrices.palindromos(4, 25);
		if (mPalindromos !=null) {
			Matrices.mostrarMatriz(mPalindromos);
		}
		else {
			System.out.println("El rango de las filas o las columnas es superior o inferior al valido(1, 26)");
		}
		Scanner sc = new Scanner(System.in);
		int filas = 0;
		while(filas < 3) {
			System.out.println("Inserte un numero de filas superior a 3");
			filas = sc.nextInt();
		}
		int columnas = 0;
		while(columnas < 3) {
			System.out.println("Inserte un numero de columnas superior a 3");
			columnas = sc.nextInt();
		}
		int [][] matriz = Matrices.rellenarMatriz(filas, columnas);
		Matrices.mostrarMatriz(matriz);
		int maxSum = Matrices.max3x3sum(matriz);
		System.out.println(maxSum);
	}

}
