package arrays;

public class MetodosOrdenacion {
	//Insercion directa
	public static void insercionDirecta(int[] array) {
        int t = array.length;
        for (int i = 1; i < t; i++) {
            int valorActual = array[i];
            int j = i - 1;
            while (j >= 0 && array[j] > valorActual) {
                array[j + 1] = array[j];
                j--;
            }
            array [j + 1] = valorActual;
        }
	}
	//Seleccion directa
	 public static void seleccionDirecta(int[] array) {
		 int t = array.length;
	        for (int i = 0; i < t - 1; i++) {
	        	int indiceMin = i;
	        	for (int j = i + 1; j < t; j++) {
	                if (array[j] < array[indiceMin]) {
	                    indiceMin = j;
	                }
	            }
	        	int temp = array[indiceMin];
	            array[indiceMin] = array[i];
	            array[i] = temp;
	        }
	 }
	 //Intercambio directo
	 public static void intercambioDirecto(int[] array) {
		 int t = array.length;
		 for (int i = 0; i < t - 1; i++) {
	            for (int j = 0; j < t - i - 1; j++) {
	                if (array[j] > array[j + 1]) {
	                	 int temp = array[j];
	                     array[j] = array[j + 1];
	                     array[j + 1] = temp;
	                }
	            }
		 }
	 }
	 public static void imprimirArray(int[] array) {
	        for (int elemento : array) {
	            System.out.print(elemento + " ");
	        }
	        System.out.println();
	    }
	 
	 public static void main(String[] args) {
		 int[] array = {3, 4, 1, 23, 6, 7};
		 System.out.println("El array es: ");
		 imprimirArray(array);
		 insercionDirecta(array);
		 System.out.println("Array ordenado por insercion directa: ");
	     imprimirArray(array);
	     array = new int[] {3, 4, 1, 23, 6, 7};
	     seleccionDirecta(array);
	     System.out.println("Array ordenado por seleccion directa: ");
	     imprimirArray(array);
	     array = new int[] {3, 4, 1, 23, 6, 7};
	     intercambioDirecto(array);
	     System.out.println("Array ordenado por intercambio directo: ");
	     imprimirArray(array);
	 }

}
