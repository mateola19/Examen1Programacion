package arrays;

import java.util.Random;

public class Ej6 {
	public static void main(String[] args) {
		int tamaño = new Random().nextInt(491) + 10;
		int[] vector = new int[tamaño];
		for (int i = 0; i < tamaño; i++) {
			vector[i] = new Random().nextInt(201) - 100;
			
		}
		if (tamaño <= 50) {
			System.out.println("El contenido del vector es: ");
			mostrar(vector);
		}
		int secuencias = contar(vector);
		System.out.println("Número de secuencias de números repetidos: " + secuencias);
		
	}
	private static void mostrar(int[] vector) {
		for (int num: vector) {
			System.out.println(num + " ");
		}
		System.out.println();
	}
	private static int contar(int[] vector) {
		int secuencias = 0;
		for (int i = 0; i < vector.length - 1; i++) {
            if (vector[i] == vector[i + 1]) {
            	 if (i == 0 || vector[i - 1] != vector[i]) {
                     secuencias++;
            	 }
            }
        }
		return secuencias;
	}

}
