package arrays;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Ej3 {
	public static void main(String [] args) {
		int tamaño = obtenerTamaño();
        int[] vector = new int[tamaño];
        long inicio = System.currentTimeMillis();
        llenarVector(vector);
        long fin = System.currentTimeMillis();
        long tiempo = fin - inicio;
        System.out.println("\nResultados:");
        System.out.println("Tamaño del vector: " + tamaño);
        System.out.println("Tiempo que ha tardado en llenarse: " + tiempo + " mils");
        long inicioCalculo = System.currentTimeMillis();
        int diferencia = calcularDiferencia(vector);
        long finCalculo = System.currentTimeMillis();
        long tiempoCalculo = finCalculo - inicioCalculo;
        System.out.println("Diferencia entre el menor y el mayor: " + diferencia);
        System.out.println("Tiempo que ha tardado en calcular la diferencia: " + tiempoCalculo + " milisegundos"); 
	}
	private static int obtenerTamaño() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Ingrese un numero comprendido entre 10 y 1000000: ");
		int t = sc.nextInt();
		while(t < 10 || t > 1000000) {
			System.out.println("Este numero esta fuera del rango, por favor introduzca otro numero entre 10 y 1000000: ");
			t = sc.nextInt();
		}
		return t;
		
	}
	private static void llenarVector(int [] vector) {
		Random r = new Random();
		int rango = 1000000 - (-999999) + 1;
		for (int i = 1; i < vector.length; i++) {
			int numAleatorio = r.nextInt(rango) + (-999999);
			while(contiene (vector, numAleatorio)) {
				numAleatorio = r.nextInt(rango) + (-999999);
			}
			vector[i] = numAleatorio;
		}
	}
	private static boolean contiene(int[] array, int elemento) {
		return Arrays.stream(array).anyMatch(x -> x == elemento);
	}
	private static int calcularDiferencia(int[] vector) {
		int minimo = Arrays.stream(vector).min().orElse(0);
        int maximo = Arrays.stream(vector).max().orElse(0);
        return maximo - minimo;
	}
}
