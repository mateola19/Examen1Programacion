package arrays;

import java.util.Scanner;

public class Ej8 {
	public static void main (String[] args) {
		String[] nombres = new String[10];
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce 10 nombres: ");
		for (int i = 0; i < 10; i++) {
			System.out.println("Nombe" + (i + 1) + ": ");
			nombres[i] = sc.nextLine();
		}
		String mayor = encontrarCadena(nombres);
		System.out.println("La cadena mas larga es: " + mayor);
		sc.close();
	}
	private static String encontrarCadena(String[] vector) {
		 if (vector == null || vector.length == 0) {
	            return null;
		 }
		 else {
			 String cadenaMayor = vector[0];
			 for (String cadena : vector) {
		            if (cadena.length() > cadenaMayor.length()) {
		                cadenaMayor = cadena;
		            }
		        }
			 return cadenaMayor;
		 }
	}

}
