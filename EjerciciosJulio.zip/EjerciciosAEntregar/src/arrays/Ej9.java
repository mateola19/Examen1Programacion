package arrays;

import java.util.Scanner;

public class Ej9 {
	
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca el tamaño del vector: ");
		int tamaño = sc.nextInt();
		System.out.println("Ingrese los elementos del vector: ");
		int []vector = new int[tamaño];
		for (int i = 0; i < tamaño; i++) {
			vector[i] = sc.nextInt();
			
		}
		Integer centro = centro(vector);
		if (centro == null ) {
			System.out.println("El vector no tiene centro");
		}
		else {
			System.out.println("El vector si tiene centro, que es: " + centro);
		}
		
	}
	/*public static Integer centro (int[] vector) {
		int suma = 0;
		int sumaMitad = 0;
		for (int j = 0; j < vector.length; j++) {
			suma += vector[j];
			
		}
		for (int i = 0; i < vector.length; i++) {
			if(sumaMitad == suma - sumaMitad) {
				return i;
			}
			sumaMitad += vector[i];
			
		}
		return null;
	}*/
	public static Integer centro (int[] vector) {
		double sumatorio = 0;
		double primerSumatorio = 0;
		double posibleCentro = 0;
		int centro = 0;
		for (int i = 0; i < vector.length; i++) {
			sumatorio += vector[i];
			primerSumatorio += vector[i] * i;
			
		}
		posibleCentro = (sumatorio != 0)? (primerSumatorio / sumatorio):0;
		centro = (int)posibleCentro;
		return (posibleCentro == centro && centro != 0)? (centro):null;
	}

}
