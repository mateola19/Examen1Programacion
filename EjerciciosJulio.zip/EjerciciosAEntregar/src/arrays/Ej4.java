package arrays;

import java.util.Scanner;

public class Ej4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese un vector comprendido entre 10 y 200: ");
		int tamaño = sc.nextInt();
		while (tamaño < 10|| tamaño > 200) {
			System.out.println("El tamaño no es valido, ingrese un tamaño entre 10 y 200: ");
			tamaño = sc.nextInt();
		}
		
		int[] vector = new int[tamaño];
		for (int i = 0; i < tamaño; i++) {
			vector[i] = (int) (Math.random()* 201) - 100;
			System.out.println("El contenido del vector es: ");
			mostrar(vector);
			int suma = sumaSin(vector);
			System.out.println("Suma sin la mala suerte: " + suma);
			sc.close();
		}
	}
	private static void mostrar(int[] vector) {
		for (int num: vector) {
			System.out.println(num + " ");
		}
		System.out.println();
	}
	private static int sumaSin(int[] vector) {
		int suma = 0;
		int cantidad = 0;
		for ( int i = 0; i < vector.length; i++) {
			if (vector[i] == 13) {
				int limite = Math.min(i + 14, vector.length);
				int sumaSub = 0;
				for(int j = i; j < limite; j++) {
					sumaSub += vector[j];
				}
				if (sumaSub != 7) {
					cantidad += (limite - i);
					i = limite - 1;
				}
			} else {
				suma += vector[i];
			}
		}
		System.out.println("La cantidad de numeros no sumados es: " + cantidad);
		return suma;
	}

}
