package arrays;

import java.util.Scanner;

public class Ej11 {
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Ingrese un numero de secuencias: ");
	        int numSec = sc.nextInt();
	        sc.nextLine();
	        int[] array = new int[1000];
	        int index = 0;
	        for (int i = 0; i < numSec; i++) {
	        	System.out.print("Ingrese la cantidad de numeros de la secuencia " + (i + 1) + " : ");
	        	int cantidadNum = sc.nextInt();
	        	sc.nextLine();
	        	System.out.print("Ingrese numeros separados por espacios: ");
	            String secuencia = sc.nextLine();
	            String[] numeros = secuencia.split(" ");
	            for (String numeroS : numeros) {
	                array[index++] = Integer.parseInt(numeroS);
	            }
	       }
	       System.out.println("El contenido del array es: ");
	       for (int j = 0; j < index; j++) {
	            System.out.print(array[j] + " ");
	        }
	       sc.close();
	 }
}
