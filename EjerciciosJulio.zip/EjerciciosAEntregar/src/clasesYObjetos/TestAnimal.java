package clasesYObjetos;

import java.time.LocalDate;

import clasesYObjetos.Animal;

public class TestAnimal {
	public static void main(String []args) {
		Animal animal = new Animal("Perro", LocalDate.of(1897, 3, 1));
		Animal animal2 = new Animal("Pez");
		 System.out.println("Animal 1: " + animal);
	     System.out.println("Animal 2: " + animal2);
	     animal2.setNombre("Gato");
	     animal.setFecha(LocalDate.of(1376, 4, 30));
	     System.out.println("Animal 1: " + animal);
	     System.out.println("Animal 2: " + animal2);
	}

}
