package clasesYObjetos;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

import clasesYObjetos.Biblioteca;
import clasesYObjetos.Libro;
import clasesYObjetos.Revista;

public class pruebaBiblioteca {
	public static void main(String []args)throws IOException {
		ArrayList <Biblioteca> b = new ArrayList();
		b.addAll((Collection<? extends Biblioteca>) new Revista (1, "Hola", "x345", 2023));
		b.addAll((Collection<? extends Biblioteca>) new Libro("Ayer", "45r6", 2020));
		b.addAll((Collection<? extends Biblioteca>) new Revista (1, "Adios", "x345", 2023));
		b.addAll((Collection<? extends Biblioteca>) new Libro("No", "45r6", 2020));
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el titulo del libro");
		String Titulo = sc.nextLine();
		for (Biblioteca p: b) {
			/*if (p instanceof Libro) {
				Libro l = (Libro)p;
			if (l.getTitulo()==Titulo)
				l.prestar();
			}
		}*/
		/*for (Biblioteca p: b) {
			System.out.println(p.toString());*/
			//polimorfismo;
			
			}
		
		
	}

}
