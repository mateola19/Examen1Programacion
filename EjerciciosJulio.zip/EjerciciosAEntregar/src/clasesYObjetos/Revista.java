package clasesYObjetos;

public class Revista {
	private int numero;
	public Revista (int numero, String Titulo, String Codigo, int AñoPublicacion) {
		super();
		this.numero = numero;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	@Override
	public String toString() {
		return super.toString() + "numero = " + numero;
		
	}

}
