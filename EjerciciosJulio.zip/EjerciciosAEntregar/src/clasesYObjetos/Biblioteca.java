package clasesYObjetos;

public class Biblioteca {
	protected String Titulo;
	protected String Codigo;
	protected int AñoPublicacion;
	public Biblioteca(String Titulo, String Codigo, int AñoPublicacion) {
		this.Titulo = Titulo;
		this.Codigo = Codigo;
		this.AñoPublicacion = AñoPublicacion;
		
	}
	public String getTitulo() { 
		return Titulo;
	}
	public String getCodigo() {
		return Codigo;
	}
	public int getAñoPublicacion() {
		return AñoPublicacion;
	}
	public void setTitulo(String Titulo) {
		this.Titulo = Titulo;
	}
	public void setCodigo(String Codigo) {
		this.Codigo = Codigo;
	}
	public void setAñoPublicacion(int AñoPublicacion) {
		this.AñoPublicacion = AñoPublicacion;
	}
	@Override
	public String toString() {
		return " Codigo = " + Codigo + " Titulo = " + Titulo + " AñoPublicacion =" + AñoPublicacion;
	}

}
