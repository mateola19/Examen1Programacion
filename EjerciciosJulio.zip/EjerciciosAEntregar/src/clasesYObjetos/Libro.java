package clasesYObjetos;

public class Libro {
	private boolean prestado;
	public Libro ( String Titulo, String Codigo, int AñoPublicacion) {
		super();
		this.prestado = false;
	}
	@Override
	public String toString() {
		return super.toString() + "prestado = " + prestado;
	}
	public boolean getPrestado() {
		return prestado;
	}
	public void prestar() {
		prestado = true;
	}
	public void devolver() {
		prestado = false;
	}
	public String getTitulo() {
		// TODO Auto-generated method stub
		return null;
	}

}
