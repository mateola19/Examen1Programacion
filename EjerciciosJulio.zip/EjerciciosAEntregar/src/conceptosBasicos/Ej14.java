package conceptosBasicos;

import java.util.Scanner;

public class Ej14 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce el número del DNI, sin la letra: ");
        int numero = scanner.nextInt();
        scanner.close();
        char[] letras = {'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};
        String letras2 = "TRWAGMYFPDXBNJZSQVHLCKE";
        int indice = numero % 23;
        char letra = letras[indice];
        System.out.println("La letra del DNI es: " + letras2.charAt(indice));
        System.out.println("La letra del DNI es: " + letra);
	}

}
