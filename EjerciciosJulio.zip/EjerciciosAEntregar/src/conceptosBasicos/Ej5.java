package conceptosBasicos;

public class Ej5 {
	public static void main(String []args) {
		double velInicial = 5.0; 
        double aceleracion = 2.0;      
        double espInicial = 5.0;   
        double tiempo = 2.0; 
        double espRecorrido = espInicial + velInicial * tiempo + 0.5 * aceleracion * Math.pow(tiempo, 2);
        System.out.println("El espacio recorrido por el vehiculo es: " + espRecorrido + " metros.");
	}

}
