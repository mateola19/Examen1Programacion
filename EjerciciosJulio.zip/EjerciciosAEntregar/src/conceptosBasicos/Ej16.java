package conceptosBasicos;

import java.util.Random;
import java.util.Scanner;

public class Ej16 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int secreto = random.nextInt(100) + 1;
        int intentos = 0;
        boolean adivinado = false;
        System.out.println("Adivina un numero secreto ubicado entre 1 y 100.");
        while (!adivinado) {
            System.out.print("Introduce un numero: ");
            int numero = scanner.nextInt();
            intentos++;
            if (numero < secreto) {
                System.out.println("El numero secreto es mayor.");
            } else if (numero > secreto) {
                System.out.println("El numero secreto es menor.");
            } else {
            	adivinado = true;
                System.out.println("Has adivinado el numero secreto (" + secreto + ") en " + intentos + " intentos.");
            }
        }
        scanner.close();
 }
}
