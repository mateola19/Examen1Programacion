package conceptosBasicos;

import java.util.Scanner;

public class Ej21 {
	 public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
		 System.out.println("Introduce un numero: ");
		 int n = scanner.nextInt();
	        long[] resultado = calcular(n);
	        System.out.println("El " + n + "-esimo termino de la serie de Fibonacci es: ");
	        for (int i = 0; i < n; i++) {
	        	System.out.println(resultado[i]);
	        }
	 }
	 public static long[] calcular(int n) {
		 long []fibonacci = new long [n];
	        /*if (n <= 0) {
	            return 0;
	        } else if (n == 1) {
	            return 1;
	        } else {
	            return calcular(n - 1) + calcular(n - 2);
	        }*/
		long termino1 = 1;
		 long termino2 = 1;
		 fibonacci [0] = termino1;
		 for (int i = 1; i < n; i++){
			 fibonacci [i] = termino2;
			 termino2 = termino1 + termino2;
			 termino1 = termino2 - termino1;
		 }
		 return fibonacci;
	  }

}
