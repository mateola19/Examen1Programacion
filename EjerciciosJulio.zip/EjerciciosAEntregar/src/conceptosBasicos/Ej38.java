package conceptosBasicos;

import java.util.Scanner;

public class Ej38 {
	static final int intentosPermitidos = 6;
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] contraseña = {"contraseña", "veintidos", "hola", "saludos", "ordenador"};
        String palabra = contraseña[(int)(Math.random() * contraseña.length)];
        System.out.println("Ingrese una palabra: ");
        String palabraAdivinada = "";
        for ( int i=0; i < palabra.length(); i++) {
        	palabraAdivinada += "_";
        	
        }
        int numeroIntentos = 0;
        while (numeroIntentos < intentosPermitidos) {
        	System.out.println("Ingrese una letra: ");
        	String letra = sc.next();
        	if (palabra.contains(letra)) {
        		for (int j = 0; j < palabra.length(); j++) {
        			if(palabra.charAt(j) == letra.charAt(0)) {
        				palabraAdivinada = palabraAdivinada.substring(0, j) + letra + palabraAdivinada.substring(j + 1);
        				System.out.println(palabraAdivinada);
        			}
        		}
        	}
        	else {
        		numeroIntentos++;
        	}
        	if (palabra.equals(palabraAdivinada)) {
        		System.out.println("Acertaste");
        		break;
        	}
        }
        if(numeroIntentos >= intentosPermitidos) {
        	System.out.println("Te quedaste sin intentos, la palabra correcta era: " + palabra);
        }
	}
	

}
