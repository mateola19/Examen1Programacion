package conceptosBasicos;

import java.util.Scanner;

public class Ej31 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese una cadena de texto: ");
        String cadena = sc.nextLine();
        buscarVocales(cadena);
        sc.close();
        
	}
	public static void buscarVocales(String cadena) {
		cadena = cadena.toLowerCase();
		char[] vocales = {'a', 'e', 'i', 'o', 'u'};
		for (char vocal:vocales) {
			int posicion = cadena.indexOf(vocal);
			while (posicion != -1) {
				System.out.println("La vocal '" + vocal + "' se encuentra en la posicion: " + (posicion + 1));
				posicion = cadena.indexOf(vocal, posicion + 1);
			}
		}
	}

}
