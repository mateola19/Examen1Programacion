package conceptosBasicos;

import java.util.Scanner;

public class Ej34 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese una frase: ");
        String frase = sc.nextLine();
        int cuentaEspacios = cuentaFrases(frase);
        System.out.println("La frase tiene " + cuentaEspacios + " espacios en blanco");
	}
	public static int cuentaFrases(String frase) {
		int contador = 0;
		for(int i = 0; i < frase.length(); i++) {
			if (frase.charAt(i) == ' ') {
				contador++;
			}
		}
		return contador;
	}

}
