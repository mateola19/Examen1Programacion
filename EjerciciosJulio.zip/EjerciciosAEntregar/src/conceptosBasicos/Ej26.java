package conceptosBasicos;

public class Ej26 {
	public static void main (String[] args) {
		int cantidad = 20;
		int [] primos = obtenerPrimos(cantidad);
		System.out.println("Los 20 primeros numeros primos son");
		for(int i = 0; i < primos.length; i++) {
			System.out.print(primos[i] + " ");
		}
	}
	public static int[] obtenerPrimos(int n) {
		int[] primos = new int[n];
        int contador = 0;
        int numero = 2;
        while(contador < n) {
        	if(esPrimo(numero)) {
        		primos[contador] = numero;
                contador++;
        	}
        	numero++;
        }
        return primos;
	}
	public static boolean esPrimo(int num) {
		if (num < 2) {
			return false;
		}
		for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
		}
		return true;
	}

}
