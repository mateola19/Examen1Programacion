package conceptosBasicos;

import java.util.Scanner;

public class Ej33 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese una frase: ");
        String frase = sc.nextLine();
        if(palindromo(frase)) {
        	System.out.println("La frase es palindroma");
        } else {
        	System.out.println("La frase no es palindroma");
        }
	}
	public static boolean palindromo(String frase) {
		frase = frase.toLowerCase().replaceAll("\\s+", "");
		frase = frase.replaceAll("[^\\p{ASCII}]", "");
		int longitud = frase.length();
		for (int i = 0; i < longitud / 2; i++) {
            if (frase.charAt(i) != frase.charAt(longitud - 1 - i)) {
                return false;
            }
		}
		return true;
	}

}
