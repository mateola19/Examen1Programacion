package conceptosBasicos;

import java.util.Scanner;

public class Ej29 {
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		final int numAlumnos = 4;
		final int numAsignaturas = 5;
		double [][] calificaciones = new double[numAlumnos][numAsignaturas];
		for (int i = 0; i < numAlumnos; i++) {
			System.out.println("Introduzca las calificaciones del alumno" + (i + 1) + ": ");
			for (int j = 0; j < numAsignaturas; j++) {
				System.out.println("Introduzca las calificaciones en la asignatura" + (j + 1) + ": ");
				calificaciones[i][j] = sc.nextDouble();
			}
		}
		double [] medias = new double[numAsignaturas];
		for (int j = 0; j < numAsignaturas; j++) {
			double suma = 0;
			for (int i = 0; i < numAlumnos; i++) {
				suma += calificaciones[i][j];
			}
			medias[j] = suma / numAlumnos;
		}
		System.out.println("Medias por asignatura");
		for (int j = 0; j < numAsignaturas; j++) {
			System.out.println("Medias " + (j + 1) + " : " + medias[j]);
		}
		sc.close();
	}

}
