package conceptosBasicos;

import java.util.Scanner;

public class Ej32 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese una palabra: ");
        String palabra = sc.nextLine();
        System.out.println("La palabra en mayusculas es: " + palabra.toUpperCase());
	}

}
