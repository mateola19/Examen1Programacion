package conceptosBasicos;

public class Ej1 {
	public static void main(String []args) {
		System.out.println("Mateo, 19, c/sal 23 4A");
	}

}
