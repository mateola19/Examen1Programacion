package conceptosBasicos;

import java.util.Scanner;

public class Ej27 {
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca la cantidad de digitos del numero secreto : ");
		int n = sc.nextInt();
		while(n < 1 && n > 5) {
			System.out.println("Numero incorrecto, introduzca un numero entre 1 y 5");
			n = sc.nextInt();
		}
		int []combinacionSecreta = generarCombinacion(n);
		int [] intentos = new int[n];
		boolean acierto = false;
		int numeroIntentos = 0;
		while (!acierto) {
			numeroIntentos ++;
			System.out.println("Intento " + numeroIntentos);
			for (int i = 0; i < n; i++) {
				System.out.println("Introduce el numero: " + (i+1));
				intentos[i] = sc.nextInt() ;
				
			}
			acierto = comprobar(combinacionSecreta, intentos );
			
			
			
		}
		System.out.println("Acertaste");
		
	}
	public static int [] generarCombinacion (int n) {
		int [] combinacion = new int[n];
		for (int i = 0; i < n; i++) {
			combinacion[i] = (int)(Math.random()* 5 + 1);
		}
		return combinacion;
	}
	public static boolean comprobar (int [] combinacion , int[] combinacionIntroducida) {
		boolean iguales = true;
		for(int i = 0; i < combinacion.length; i++) {
			if (combinacion[i] != combinacionIntroducida[i]) {
				iguales = false;
			}
		}
		return iguales;
	}
	

}
