package conceptosBasicos;

import java.util.Scanner;

public class Ej13 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        System.out.println("Introduce la cantidad de numeros a sumar: ");
        int n = sc.nextInt();
        if (n<=0) {
        	System.out.println("La cantidad de numeros solo puede ser un entero");
        	return;
        }
        double suma = 0.0;
        for(int i = 1; i <= n; i++) {
        	System.out.println("Ingrese el numero " +i+ " : ");
        	double numero = sc.nextDouble();
        	suma += numero;
        }
        double media = suma/n;
        System.out.println("La suma de los numeros es: " + suma);
        System.out.println("La media de los numeros es: " + media);
        sc.close();
	}

}
