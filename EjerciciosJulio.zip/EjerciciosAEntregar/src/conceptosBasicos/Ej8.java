package conceptosBasicos;

import java.util.Scanner;

public class Ej8 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca un color en formato rgb sin espacios entre las comas(ej 255,17,0): ");
        String linea = sc.next();
        int r = Integer.parseInt(linea.split(",")[0]);
        int g = Integer.parseInt(linea.split(",")[1]);
        int b = Integer.parseInt(linea.split(",")[2]);
        
        double y = 0.299*r + 0.587*g + 0.114*b;
        double i = 0.596*r - 0.275*g - 0.321*b;
        double q = 0.212*r - 0.528*g + 0.311*b;
        
        System.out.println("La solucion a y es: " + y);
        System.out.println("La solucion a i es: " + i);
        System.out.println("La solucion a q es: " + q);
	}
}
