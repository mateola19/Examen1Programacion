package conceptosBasicos;

import java.util.Scanner;

public class Ej7 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduzca la masa 1: ");
        double masa1 = scanner.nextDouble();
        System.out.println("Introduzca la masa 2: ");
        double masa2 = scanner.nextDouble();
        System.out.println("Introduzca la distancia: ");
        double distancia = scanner.nextDouble();
        final double G = 6.673E-11;
        double fuerza = G * (masa1 * masa2)/Math.pow(distancia, 2);
        System.out.println("La fuerza es igual a: "+ fuerza);
 }

}
