package conceptosBasicos;

import java.util.Scanner;

public class Ej3 {
	public static void main(String []args) {
		final double Cambio = 1.18;
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese una cantidad en euros: ");
		double euros = sc.nextDouble();
		double dolares = euros * Cambio;
		System.out.printf("%.2f euros son %.2f dolares%n", euros, dolares);
		sc.close();
	}

}
