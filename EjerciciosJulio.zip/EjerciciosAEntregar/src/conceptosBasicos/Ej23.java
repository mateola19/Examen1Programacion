package conceptosBasicos;

import java.util.Scanner;

public class Ej23 {
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce la coordenada x: ");
		double x = sc.nextDouble();
		System.out.println("Introduce la coordenada y: ");
		
		double y = sc.nextDouble();
		double [] polares = coordenadasPolares(x, y);
		System.out.println("Las coordenadas polares son: " + polares[0] + " " + polares[1]);
		
	}
	public static double[] coordenadasPolares (double x, double y) {
		double r = Math.sqrt(x*x + y*y);
		double angulo = Math.atan2(y, x);
		double polarX = r* Math.cos(angulo);
		double polarY = r* Math.sin(angulo);
		double [] polares = {polarX, polarY};
		return polares;
	}

}
