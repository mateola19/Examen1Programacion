package conceptosBasicos;

import java.util.Scanner;

public class Ej20 {
	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Introduce el tamaño del lado del triangulo: ");
		int lado = scanner.nextInt();
		 for (int i = lado; i >= 1; i--) {
			 /*for (int s = 1; s <= lado - i; s++) {
				 System.out.print(" ");
			 }*/
			 for (int j = 1; j <= i; j++) {
				 System.out.print("*");
			 }
			 System.out.println( );
		 }
	}

}
