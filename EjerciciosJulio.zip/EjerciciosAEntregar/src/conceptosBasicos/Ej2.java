package conceptosBasicos;

public class Ej2 {
	public static void main(String []args) {
		double div = 1234.0 / 532.0;
		System.out.printf("El resultado es: %.15f", div);
	}
}
