package conceptosBasicos;

import java.util.Scanner;

public class Ej36 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese la primera palabra: ");
        String palabra1 = sc.nextLine();
        System.out.println("Ingrese la segunda palabra: ");
        String palabra2 = sc.nextLine();
        if (palabra1.length() < palabra2.length()) {
        	System.out.println("La primera palabra tiene menos caracteres que la segunda");
        }
        else if (palabra2.length() < palabra1.length()) {
        	System.out.println("La segunda palabra tiene menos caracteres que la primera");
        } else {
        	System.out.println("Tienen la misma cantidad de caracteres");
        }
        sc.close();
	}

}
