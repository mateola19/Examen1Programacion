package conceptosBasicos;

import java.util.Scanner;

public class Ej24 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca la constante a: ");
        double a = sc.nextDouble();
        System.out.println("Introduzca la constante b: ");
        double b = sc.nextDouble();
        System.out.println("Introduzca la constante c: ");
        double c = sc.nextDouble();
        calcular (a,b,c);
        
        
	}
	public static void calcular(double a, double b, double c) {
        double discriminante = b * b - 4 * a * c;
        if (discriminante > 0) {
            double raiz = Math.sqrt(discriminante);
            double ecuacion = (-b + raiz) / (2 * a);
            double ecuacion2 = (-b - raiz) / (2 * a);
            System.out.println("Las raices son: " + ecuacion + " y " + ecuacion2);
        } else if (discriminante == 0) {
            double ecuacion = -b / (2 * a);
            System.out.println("La ecuacion tiene una doble raiz: " + ecuacion);
        } else {
            System.out.println("La ecuacion no tiene solucion para los numeros reales.");
        }
    }
}
