package conceptosBasicos;

import java.util.Scanner;

public class Ej22 {
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce las cordenadas del primer punto: ");
		double x1 = sc.nextDouble();
		double y1 = sc.nextDouble();
		System.out.println("Introduce las cordenadas del segundo punto: ");
		double x2 = sc.nextDouble();
		double y2 = sc.nextDouble();
		double distancia = calcularDistancia(x1, y1, x2, y2);
		System.out.println("La distancia euclidiana entre los dos puntos es: " + distancia);
		sc.close();
	}
	public static double calcularDistancia(double x1, double x2, double y1, double y2) {
		double diferenciaX = x2 - x1;
		double diferenciaY = y2 - y1;
		double distancia = Math.sqrt(Math.pow(diferenciaX, 2) - Math.pow(diferenciaY, 2));
		return distancia;
	}

}
