package conceptosBasicos;

import java.util.Scanner;

public class Ej12 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el valor de n: ");
        int n = sc.nextInt();
        double suma = 0.0;
        for(int i = 1; i <= n; i++) {
        	suma += 1.0/i;
        }
        System.out.println("La suma de la serie es: " + suma);
        sc.close();
	}

}
