package conceptosBasicos;

public class Ej28 {
	public static void main (String[] args) {
		int n = 4;
		int m = 3;
		int [][] array = new int [n][m];
		for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                array[i][j] = i + j;
            }
        }
		for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(array[i][j] + " ");
            }
            System.out.println();
        }
	}

}
