package conceptosBasicos;

import java.util.Scanner;

public class Ej35 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String contraseña = "añesartnoc";
        int longitud = contraseña.length();
        boolean[] aciertos = new boolean[longitud];
        System.out.println("Adivine la contraseña");
        while(true) {
        	System.out.println("Ingrese una palabra: ");
        	String intento = sc.nextLine();
        	if(intento.equals(contraseña)) {
        		System.out.println("Acertaste");
        		break;
        	} else {
        		int letrasCorrectas = 0;
        		for (int i = 0; i < longitud && i < intento.length(); i++) {
        			if (intento.charAt(i) == contraseña.charAt(i)) {
        				aciertos[i] = true;
        				letrasCorrectas++;
        			} else {
        				aciertos[i] = false;
        			}
        		}
        		System.out.println("Acertaste " + letrasCorrectas + " letras");
        		for (int i = 0; i < longitud; i++) {
        			if(aciertos[i]) {
        				System.out.print(contraseña.charAt(i));
        			} else {
        				System.out.print("-");
        			}
        		}
        		System.out.println();
        	}
        }
        sc.close();
	}

}
