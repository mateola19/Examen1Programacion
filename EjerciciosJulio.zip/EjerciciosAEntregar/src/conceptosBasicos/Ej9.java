package conceptosBasicos;

import java.util.Scanner;

public class Ej9 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el valor del examen en %: ");
        double valorExamen = sc.nextDouble();
        System.out.println("Ingrese el valor de las tareas en %: ");
        double valorTareas = sc.nextDouble();
        System.out.println("Ingrese el numero de tareas realizadas: ");
        int numTareas = sc.nextInt();
        double[] notasMateria = new double[3];
        for (int i = 0; i < 3; i++) {
            System.out.println("Introduce la nota del examen de la materia " + (i + 1) + ": ");
            double notaExamen = sc.nextDouble();
            double sumaTareas = 0;
            for (int j = 0; j < numTareas; j++) {
                System.out.println("Introduce la nota de la tarea " + (j + 1) + " de la materia " + (i + 1) + ": ");
                sumaTareas += sc.nextDouble();
            }
            double notaTareas = sumaTareas / numTareas;
            double notaFinalMateria = (notaExamen * valorExamen / 100) + (notaTareas * valorTareas / 100);
            notasMateria[i] = notaFinalMateria;
        }
        double sumaNotas = 0;
        for (double nota : notasMateria) {
            sumaNotas += nota;
        }
        double notaMediaGlobal = sumaNotas / 3;
        System.out.println("Notas medias por materia:");
        for (int i = 0; i < 3; i++) {
            System.out.printf("Materia %d: %.2f\n", (i + 1), notasMateria[i]);
        }
        System.out.printf("Nota media global: %.2f\n", notaMediaGlobal);
        sc.close();
	}

}
