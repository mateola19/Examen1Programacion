package conceptosBasicos;

import java.util.Scanner;

public class Ej11 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un  numero: ");
        double n = sc.nextDouble();
        if (n < 0) {
        	System.out.println("El numero es negativo");
        		
        	}
        else if(n == 0) {
        	System.out.println("El numero es 0");
        	}
        else {
        	System.out.println("El numero es positivo");
        }
    }
}


