package conceptosBasicos;

import java.util.Scanner;

public class Ej37 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese una frase: ");
        String frase = sc.nextLine();
        buscarLetras(frase);
        sc.close();
	}
	public static void buscarLetras(String frase) {
		frase = frase.toLowerCase();
		char[] letras = {'a', 'e', 'i', 'o', 'u', 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'ñ', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z'};
		for (char letra:letras) {
			int posicion = frase.indexOf(letra);
			while (posicion != -1) {
				System.out.println("La vocal '" + letra + "' se encuentra en la posicion: " + (posicion + 1));
				posicion = frase.indexOf(letra, posicion + 1);
			}
		}
	}

}
