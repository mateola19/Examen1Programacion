package conceptosBasicos;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Ej30 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String [] lineas = new String [4];
        	
        for (int i = 0; i < 4; i++) {
        	System.out.println("Ingrese la linea " + (i + 1) + " : ");
        	lineas[i] = sc.nextLine();
        	while(lineas[i].length() > 50) {
        		System.out.println("La cadena de caracteres introducida es invalida, por favor introduzca una nueva "
        				+ "de 50 caracteres o menos");
        		lineas[i] = sc.nextLine();
        	}
        }
        Arrays.sort(lineas, Comparator.comparingInt(String::length));
        System.out.println("Lineas ordenadas por longitud: ");
        for(String linea : lineas) {
        	System.out.println(linea);
        }
        sc.close();
	}

}
