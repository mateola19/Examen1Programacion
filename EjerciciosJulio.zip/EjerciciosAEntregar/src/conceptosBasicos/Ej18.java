package conceptosBasicos;

import java.util.Scanner;

public class Ej18 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int edad;
        int sumaEdades = 0;
        int cantidadAlumnos = 0;
        int mayores18 = 0;
        System.out.println("Introduzca las edades de los alumnos, para parar introduzca un numero negativo: ");
        while (true) {
        	System.out.println("Edad del alumno: ");
        	edad = sc.nextInt();
        	if (edad < 0) {
        		break;
        	}
        	sumaEdades += edad;
        	cantidadAlumnos++;
        	if (edad > 18) {
        		mayores18++;
        	}
        }
        if (cantidadAlumnos > 0) {
        	double media = (double) sumaEdades / cantidadAlumnos;
        	System.out.println("Suma de edades: " + sumaEdades);
            System.out.println("Media de edades: " + media);
            System.out.println("Numero de alumnos mayores de 18 años: " + mayores18);
            
        }else {
        	System.out.println("No se introdujo la edad de ningun alumno");
        }
        sc.close();
	}

}
