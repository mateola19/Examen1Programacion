package conceptosBasicos;

import java.util.Scanner;

public class Ej6 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduzca el radio de la circunferencia: ");
        double radio = scanner.nextDouble();
        double perimetro = 2 * Math.PI * radio;
        double area = Math.PI * Math.pow(radio, 2);
        System.out.println("El perimetro de la circunferencia es igual a: "+ perimetro);
        System.out.println("El area de la circunferencia es igual a: " + area);
  }

}
