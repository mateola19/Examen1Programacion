package conceptosBasicos;

import java.util.Scanner;

public class Ej10 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca la constante a: ");
        double a = sc.nextDouble();
        System.out.println("Introduzca la constante b: ");
        double b = sc.nextDouble();
        System.out.println("Introduzca la constante c: ");
        double c = sc.nextDouble();
        double discriminante = b*b-4*a*c;
        if (discriminante > 0) {
        	double raiz = Math.sqrt(b*b - 4*a*c);
            double ecuacion = (-b + raiz)/2*a;
            double ecuacion2 = (-b - raiz)/2*a;
            System.out.println("La ecuacion es: " + ecuacion);
            System.out.println("La ecuacion es: " + ecuacion2);
        	
        }
        else {
        	System.out.println("La ecuacion no tiene solucion");
        }
        
        
	}
}
