package conceptosBasicos;

import java.util.Scanner;

public class Ej17 {
	 public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Ingresa tu nombre: ");
		 long tiempo = System.currentTimeMillis();
		 String nombre = sc.next();
		 
		 long tiempoFin = System.currentTimeMillis();
		 long duracionMilisegundos = tiempoFin - tiempo;
		 long segundos = duracionMilisegundos / 1000;
	     long milisegundos = duracionMilisegundos % 1000;
	     String duracion = String.format("%d.%03d", segundos, milisegundos);
	     System.out.println("Hola, " + nombre + "!has tardado " + duracion + " segundos en contestar.");
	}
}
