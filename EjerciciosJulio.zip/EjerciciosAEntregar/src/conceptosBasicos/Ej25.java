package conceptosBasicos;

import java.util.Scanner;

public class Ej25 {
	public static void main (String[] args) {
		int[] numeros = new int[10];
		introducirNumeros(numeros);
		System.out.println("Este el array original: ");
		mostrarArray(numeros);
		invertirArray(numeros);
		System.out.println("Array invertido: ");
		mostrarArray(numeros);
		
	}
	private static void introducirNumeros(int[] array) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce 10 numeros enteros");
		for (int i = 0; i < array.length; i++) {
            System.out.print("Numero " + (i + 1) + ": ");
            array[i] = sc.nextInt();
        }
	}
	private static void invertirArray(int[] array) {
		int longitud = array.length;
		for (int i = 0; i < longitud / 2; i++) {
			int temp = array[i];
            array[i] = array[longitud - 1 - i];
            array[longitud - 1 - i] = temp;
		}
	}
	private static void mostrarArray(int[] array) {
		for (int numero : array) {
            System.out.print(numero + " ");
        }
		System.out.println();
	}

}
