package conceptosBasicos;

public class Ej4 {
	public static void main(String[] args) {
        int altura = 5;
        int anchura = 3;
        for (int i = 0; i < altura; i++) {
        	for (int j = 0; j < anchura; j++) {
        		 if (j == anchura / 2 || i == altura - 1 || (i == 1 && j == 0)) {
        			 System.out.print("*");
        		 }
        		 else {
        			 System.out.print(" ");
        		 }
        	}
        	System.out.println();
        }
	}

}


