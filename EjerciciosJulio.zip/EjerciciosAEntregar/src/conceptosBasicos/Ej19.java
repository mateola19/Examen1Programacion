package conceptosBasicos;

import java.util.Scanner;

public class Ej19 {
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Introduce un numero: ");
		 int numero = sc.nextInt();
		 sc.close();
		 int suma = 0;
		 for(int i = 1; i <= numero; i++) {
			 suma += i;
			 
		 }
		 System.out.println("La suma de todos los numeros de 1 a " + numero + " es: " + suma);
	}
}
