package expresionesRegulares;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;

public class Ej2 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<String> fechas = new ArrayList<String>();
        System.out.println("Ingrese fechas (escriba fin para finalizar): ");
        String fechaLeida = "";
        do{
        	fechaLeida = sc.nextLine();
        	if (!fechaLeida.equals("fin") ){
        		fechas.add(fechaLeida);
        	}
        }while(!fechaLeida.equals("fin"));
        
        //String regex ="^(\\d{2}[-/]\\p{Alpha}{3}[-/]\\d{4})$";
        String regex ="^(0[1-9]|[12]\\d|3[01])(\\/|-)(0[1-9]|1[1-9]|\\p{Alpha}{3})\\2\\d{4}$";
        Pattern patern = Pattern.compile(regex);
        for(String fecha : fechas) {
        	 Matcher match = patern.matcher(fecha);
             System.out.print(fecha + " : ");
             if (match.matches()) {
             	System.out.println("valida");
             }
             else {
            	 System.out.println("invalida");
             }
        }
       
        sc.close();
	}

}
