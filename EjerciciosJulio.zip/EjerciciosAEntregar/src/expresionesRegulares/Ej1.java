package expresionesRegulares;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ej1 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce una línea formada por varios nombres separados por comas( "
        		+ "que cumplan las siguientes reglas: "
        		+ "Está formado por dos o más palabras, Cada palabra comienza por una letra mayúscula "
        		+ "seguida de letras minúsculas"
        		+ ",Cada palabra debería tener al menos dos letras,"
        		+ " Las palabras se separan entre sí por un único espacio en blanco.) : ");
        String linea = sc.nextLine();
        String regex ="\\b[A-Z][a-z]{1,}[ ]+[A-Z][a-z]{1,}(?: [A-Z][a-z]{1,})*\\b";
        Pattern patern = Pattern.compile(regex);
        Matcher match = patern.matcher(linea);
        System.out.println("Los nombres validos son: ");
        while (match.find()) {
        	System.out.println(match.group());
        }
        sc.close();
	}

}
