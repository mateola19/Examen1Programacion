package expresionesRegulares;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class Ej7 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine().trim();

        String[] boletos = input.split("\\s*,\\s*"); // Separar boletos por comas

        for (String boleto : boletos) {
            if (esBoletoValido(boleto)) {
                System.out.println(obtenerPremio(boleto));
            } else {
                System.out.println(boleto + " NO VÁLIDO");
            }
        }
    }

    public static boolean esBoletoValido(String boleto) {
        String regex = "^.*([$&@#]{6,}).*\\1.*$"; // Expresión regular

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(boleto);

        return matcher.matches();
    }

    public static String obtenerPremio(String boleto) {
        String regex = "([$&@#]{6,})"; // Expresión regular para la secuencia premiada

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(boleto);

        if (matcher.find()) {
            String secuencia = matcher.group(1);
            int longitud = secuencia.length();

            if (longitud == 10) {
                return secuencia + " BOTE!";
            } else {
                return secuencia + " (" + longitud + ")";
            }
        } else {
            return "NO VÁLIDO";
        }
    }

}
