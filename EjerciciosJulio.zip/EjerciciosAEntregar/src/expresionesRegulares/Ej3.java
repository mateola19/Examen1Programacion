package expresionesRegulares;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Map;
import java.util.Scanner;
import java.util.HashMap;

public class Ej3 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        double costeTotal = 0.0;

        System.out.println("Introduce los datos de los muebles (formato: >>nombre del mueble<<precio:cantidad):");
        System.out.println("Escribe 'comprar' para finalizar la entrada.");
        // Expresión regular
        String regex = ">>([a-zA-Z ]+)<<(\\d+(\\,\\d{1,2})?):(\\d+)";

        Pattern pattern = Pattern.compile(regex);
        Map<String, Integer> mueblesComprados = new HashMap();

        while (true) {
            String linea = scanner.nextLine().trim();

            if (linea.equalsIgnoreCase("comprar")) {
                break;
            }

            Matcher matcher = pattern.matcher(linea);
            if (matcher.matches()) {
                String nombreMueble = matcher.group(1);
                double precio = Double.parseDouble(matcher.group(2).replace(",", "."));
                int cantidad = Integer.parseInt(matcher.group(4));
                if(mueblesComprados.containsKey(nombreMueble)){
                    //Recuperamos catidad
                    Integer cantidadAnterior = mueblesComprados.get(nombreMueble);
                    mueblesComprados.put(nombreMueble, (cantidadAnterior + cantidad));
                }else{
                    mueblesComprados.put(nombreMueble, cantidad);
                }

                double costoMueble = precio * cantidad;
                costeTotal += costoMueble;
            } else {
                System.out.println("Formato incorrecto. Introduce nuevamente.");
            }
        }
        System.out.println("\nCompra:");
        System.out.println(mueblesComprados.toString());
        System.out.println("Importe total:");
        // Agrega aquí la lógica para mostrar los muebles ingresados
        System.out.println(costeTotal + "€");
	}
}
