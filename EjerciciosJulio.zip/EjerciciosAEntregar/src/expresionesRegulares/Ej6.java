package expresionesRegulares;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;


public class Ej6 {
	public static void main(String[] args) {
		if(args.length != 1) {
			System.out.println("");
			return;
		}
		//String path = "C:\\Users\\Usuario\\eclipse-workspace\\EjerciciosAEntregar\\src\\expresionesRegulares\\textoPrueba.txt";
		String path = args[0];
		try {
			BufferedReader reader = new BufferedReader(new FileReader(path));
			String line;
			boolean upercase = false;
			while((line = reader.readLine()) != null) {
				while (line.contains("<uppercase>") && line.contains("</uppercase>")) {
					int start = line.indexOf("<uppercase>");
					int end = line.indexOf("</uppercase>");
					String text = line.substring(start + "<upercase>".length() + 1, end);
					String upercaseText = text.toUpperCase();
					line = line.substring(0, start) + upercaseText + line.substring(end + "</uppercase>".length());  
				}
			System.out.println(line);
			}
			reader.close();
		}catch (IOException e) {
			System.out.println("Error al leer el archivo: " + e.getMessage());
		}
	} 

}
