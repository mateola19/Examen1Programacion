package expresionesRegulares;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ej5_2 {
	public static void main(String[] args) {
		if(args.length != 1) {
			System.out.println("Error, debes pasar la ruta del archivo como argumento");
			return;
		}
		String path = args[0];
		File file = new File(path);
		try {
			Scanner sc = new Scanner(file);
			//Pattern patern = Pattern.compile("<a[^>]href=\"([^\"])\"[^>]*>");
			Pattern patern = Pattern.compile("<a\\s+(?:[^>]?\\s+)?href=\"([^\"])\"");
			while(sc.hasNextLine()) {
				String line = sc.nextLine();
				Matcher match = patern.matcher(line);
				while(match.find())	{
					String link = match.group(1);
					System.out.println(link);
				}
				
			}
			sc.close();
		} catch (FileNotFoundException e) {
			System.out.println("No se pudo encontrar el archivo: " + path);
		}
	}

}
