package expresionesRegulares;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ej4 {
	public static void main(String[] args) {
		if(args.length != 1) {
			System.err.println("Error, debes pasar la ruta del archivo como argumento");
			System.exit(1);
		}
		String path = args[0];
		//String path = "C:\\Users\\Usuario\\eclipse-workspace\\EjerciciosAEntregar\\src\\expresionesRegulares\\ficheroPrueba.html";
		try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
			String line;
			StringBuilder html = new StringBuilder();
			while((line = reader.readLine()) != null) {
				html.append(line);
			}
			String regex ="(http|https)://[a-zA-Z0-9\\./\\?#=_-]+";
			Pattern patern = Pattern.compile(regex);
	        Matcher match = patern.matcher(html.toString());
	        System.out.println("Url encontradas: ");
	        while (match.find()) {
                System.out.println(match.group());
            }
		}catch (IOException e) {
            System.err.println("Hubo un error al leer el archivo: " + e.getMessage());
		}
	}

}
