package Colecciones1;

import java.util.*;

public class Ej8 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);        
        Map<String, Set<String>> manosJugadores = new HashMap<>();
        System.out.println("Ingrese los naipes de los jugadores (nombre: RP RP RP ... RP),"
        		+ " escriba 'fin' para finalizar:");
        while (true) {
            String entrada = sc.nextLine();
            if (entrada.equals("fin")) {
                break;
            }           
            String[] partes = entrada.split(":");
            String nombreJugador = partes[0].trim();
            String[] naipes = partes[1].trim().split("\\s+");
            Set<String> manoJugador = new HashSet<>();
            Collections.addAll(manoJugador, naipes);
          //Si ya existe el jugador, actualizamos sus manos
            if(manosJugadores.containsKey(nombreJugador)){
                Set<String> manoJugadorAnterior =  manosJugadores.get(nombreJugador);
                manoJugador.addAll(manoJugadorAnterior);
            }
            manosJugadores.put(nombreJugador, manoJugador);
        }
        Map<String, Integer> valorManos = new HashMap<>();
        for (Map.Entry<String, Set<String>> entry : manosJugadores.entrySet()) {
            String jugador = entry.getKey();
            Set<String> mano = entry.getValue();
            int valorMano = calcularValorMano(mano);
          //Si existe el jugador, actualizamos el valor de su mano
            if (valorManos.containsKey(jugador)) {
                valorMano += valorManos.get(jugador);
            }
            valorManos.put(jugador, valorMano);
        }
        System.out.println("\nValor de las manos de los jugadores:");
        for (Map.Entry<String, Integer> entry : valorManos.entrySet()) {
            String jugador = entry.getKey();
            int valorMano = entry.getValue();
            System.out.println(jugador + " : " + valorMano);
        }
        sc.close();
    }
    private static int calcularValorMano(Set<String> mano) {
        int valorMano = 0;
        Map<String, Integer> valorRangos = new HashMap<>();
        valorRangos.put("2", 2);
        valorRangos.put("3", 3);
        valorRangos.put("4", 4);
        valorRangos.put("5", 5);
        valorRangos.put("6", 6);
        valorRangos.put("7", 7);
        valorRangos.put("8", 8);
        valorRangos.put("9", 9);
        valorRangos.put("10", 10);
        valorRangos.put("J", 11);
        valorRangos.put("Q", 12);
        valorRangos.put("K", 13);
        valorRangos.put("A", 14);     
        for (String naipe : mano) {
        	String rango = naipe.length() > 2 ? String.valueOf(naipe.charAt(0)) + naipe.charAt(1) 
        	: String.valueOf(naipe.charAt(0));
            char palo = naipe.charAt(naipe.length() -1);
            int valorRango = valorRangos.get(rango);
            int valorPalo = calcularValorPalo(palo);
            valorMano += valorRango * valorPalo;
        }
        return valorMano;
    }
    private static int calcularValorPalo(char palo) {
        switch (palo) {
            case 'S':
                return 4;
            case 'H':
                return 3;
            case 'D':
                return 2;
            case 'C':
                return 1;
            default:
                return 0;
        }
    }
}


