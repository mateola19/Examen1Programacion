package Colecciones1;

import java.util.*;

public class Ej7 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca una cantidad de elementos para los dos conjuntos: ");
        String [] cantidades = sc.nextLine().split(" ");
        int n = Integer.parseInt(cantidades[0]);
        //System.out.println("Introduzca una cantidad de elementos para el segundo conjunto(m): ");
        int m = Integer.parseInt(cantidades[1]);
        Set<Integer> conjunto1 = new HashSet<>();
        Set<Integer> conjunto2 = new HashSet<>();
        System.out.println("Introduzca los elementos de los conjuntos: ");
        String [] elementos = sc.nextLine().split(" ");
        for (int i = 0; i < n; i++) {
            conjunto1.add(Integer.parseInt(elementos[i]));
        }
        //System.out.println("Introduzca los " + m + " elementos del segundo conjunto: ");
        for (int i = n; i < elementos.length; i++) {
            conjunto2.add(Integer.parseInt(elementos[i]));
        }
        System.out.println("Elementos que estan en ambos conjuntos: ");
        for (int num : conjunto1) {
            if (conjunto2.contains(num)) {
                System.out.print(num + " ");
            }
        }
        sc.close();
    }
}


