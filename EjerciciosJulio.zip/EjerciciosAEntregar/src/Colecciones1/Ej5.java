package Colecciones1;

import java.util.*;

public class Ej5 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese la secuencia: ");
        String secuencia = sc.nextLine();
        String[] arrayNumeros = secuencia.split(" ");
        int N = Integer.parseInt(arrayNumeros[0]);
        int K = Integer.parseInt(arrayNumeros[1]);
        int X = Integer.parseInt(arrayNumeros[2]);
        Queue<Integer> cola = new LinkedList<>();
        String [] arrayNumeros2 = sc.nextLine().split(" ");
        for (int i = 0; i < N; i++) {
            cola.offer(Integer.parseInt(arrayNumeros2[i]));
        }
        for (int i = 0; i < K; i++) {
            cola.poll();
        }
        boolean encontrado = cola.contains(X);
        if (encontrado) {
            System.out.println("true");
        } else {
            if (!cola.isEmpty()) {
                int minimo = Integer.MAX_VALUE;
                for (int num : cola) {
                    minimo = Math.min(minimo, num);
                }
                System.out.println(minimo);
            } else {
                System.out.println("0");
            }
        }
        sc.close();
    }
}


