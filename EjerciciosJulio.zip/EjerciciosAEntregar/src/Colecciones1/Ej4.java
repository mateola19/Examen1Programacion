package Colecciones1;

import java.util.*;

public class Ej4 {
	public static void main(String[] args) {
        Palabras palabras = new Palabras();
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un comando: (añadir, lista n, borrar, borrar:, fin)");
        String comando = "";
        String lineaPalabras = "";
        Integer longitud = 0;
        while(!comando.equals("fin")) {
            String[] comandos = sc.nextLine().split(":");
        	if (comandos.length > 1) {
            	comando = comandos[0];
            	lineaPalabras = comandos[1];
            }
            else {
            	String[] comando2 = comandos[0].split("\\s+");
            	comando = comando2[0];
            	if (comando2.length > 1) {
                	longitud = Integer.parseInt(comando2[1]);
            	}
            }
            switch(comando) {
            	case "añadir":
            		palabras.agregarPalabras(lineaPalabras);
            		break;
            	case "lista":
            		List<String> listaPalabras = palabras.obtenerLista(longitud);
            		for (int i = 0; i < listaPalabras.size(); i++) {
            			System.out.print(listaPalabras.get(i) + ",");
            		}
            		System.out.println();
            		break;
            	case "borrar":
            	case "fin":
            		palabras.borrarPalabras();
            		if(!lineaPalabras.isEmpty()) {
            			palabras.agregarPalabras(lineaPalabras);        			
            		}
            		break;
            }
        }
        
    }
	 
	    
}

