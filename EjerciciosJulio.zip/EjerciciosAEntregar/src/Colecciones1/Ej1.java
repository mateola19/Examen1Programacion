package Colecciones1;

import java.util.*;

public class Ej1 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca la cantidad de nombres: ");
        int cantidad = sc.nextInt();
        //System.out.println("Introduzca los nombres");
        sc.nextLine();
        Set<String> nombres = new LinkedHashSet<>();
        for (int i = 0; i < cantidad; i++) {
            String nombre = sc.nextLine();
            nombres.add(nombre);
        }
        for (String nombre : nombres) {
            System.out.println(nombre);
        }
        sc.close();
    }
}

