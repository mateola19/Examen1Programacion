package Colecciones1;

import java.util.*;

public class Ej3 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce una linea de texto: ");
        String linea = sc.nextLine();
        String[] palabras = linea.split("\\s+");
        Set<String> palabrasUnicas = new HashSet<>();
        Set<String> palabrasRepetidas = new HashSet<>();
        for (String palabra : palabras) {
            if (!palabrasUnicas.contains(palabra)) {
                palabrasUnicas.add(palabra);
            } else {
                palabrasRepetidas.add(palabra);
                palabrasUnicas.remove(palabra);
            }
        }
        System.out.println("Las palabras que no se repiten son: " + palabrasUnicas);
        System.out.println("Las palabras que se repiten son: " + palabrasRepetidas);
        sc.close();
    }
}


