package Colecciones1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Palabras {
	private Map<Integer, List<String>> palabrasLongitud;
    
	public Palabras() {
        palabrasLongitud = new HashMap<>();
    }
    public Palabras(String texto) {
        palabrasLongitud = new HashMap<>();
        agregarPalabras(texto);
    }
    public void agregarPalabra(String palabra) {
        int longitud = palabra.length();
        if (!palabrasLongitud.containsKey(longitud)) {
            palabrasLongitud.put(longitud, new ArrayList<>());
        }
        if (!palabrasLongitud.get(longitud).contains(palabra)) {
            palabrasLongitud.get(longitud).add(palabra);
            Collections.sort(palabrasLongitud.get(longitud));
        }
    }
    public Map<Integer, List<String>> getPalabrasLongitud() {
		return palabrasLongitud;
	}
	public void setPalabrasLongitud(Map<Integer, List<String>> palabrasLongitud) {
		this.palabrasLongitud = palabrasLongitud;
	}
	public void agregarPalabras(String texto) {
        String[] palabras = texto.split("\\s+");
        for (String palabra : palabras) {
            agregarPalabra(palabra);
        }
    }
    public boolean contienePalabra(String palabra) {
        int longitud = palabra.length();
        return palabrasLongitud.containsKey(longitud) && palabrasLongitud.get(longitud).contains(palabra);
    }
    public List<String> obtenerLista(int longitud) {
        return palabrasLongitud.getOrDefault(longitud, new ArrayList<>());
    }
    public void borrarPalabras() {
        palabrasLongitud.clear();
    }

}
