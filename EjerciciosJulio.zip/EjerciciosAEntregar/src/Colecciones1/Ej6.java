package Colecciones1;

import java.util.*;

public class Ej6 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Map<String, List<String>> contactos = new TreeMap<>();
        System.out.println("Bienvenido al gestor de contactos telefonicos.");
        System.out.println("Por favor, ingrese un comando o escriba 'salir' para finalizar.");
        boolean salir = false;
        while (!salir) {
            System.out.print("> ");
            String comando = sc.nextLine().trim();
            String[] partes = comando.split(":");
            String operacion = partes[0].toLowerCase().trim();
            String datos = partes.length > 1 ? partes[1].trim() : "";
            switch (operacion) {
                /*case "añadir":
                    agregarContacto(datos, contactos);
                    break;*/
                case "buscar":
                    buscarContacto(datos, contactos);
                    break;
                case "eliminar":
                    eliminarContacto(datos, contactos, sc);
                    break;
                case "contactos":
                    mostrarContactos(contactos);
                    break;
                case "salir":
                    salir = true;
                    break;
                default:
                	agregarContacto(comando, contactos);
                	
                    //System.out.println("Comando no reconocido. Por favor, intentelo de nuevo.");
            }
        }
        System.out.println("¡Adios!");
        sc.close();
    }
    private static void agregarContacto(String datos, Map<String, List<String>> contactos) {
        String[] partes = datos.split(":");
        if (partes.length == 2) {
            String nombre = partes[0].trim();
            String telefono = partes[1].trim();
            contactos.putIfAbsent(nombre, new ArrayList<>());
            if (!contactos.get(nombre).contains(telefono)) {
                contactos.get(nombre).add(telefono);
                System.out.println("Contacto agregado correctamente.");
            } else {
                System.out.println("El telefono especificado ya existe para este contacto.");
            }
        } else {
            System.out.println("Formato de comando incorrecto. Debe ser 'nombre:telefono'.");
        }
    }
    private static void buscarContacto(String nombre, Map<String, List<String>> contactos) {
        if (contactos.containsKey(nombre)) {
            List<String> telefonos = contactos.get(nombre);
            System.out.println("Telefono(s) de " + nombre + ": " + String.join(", ", telefonos));
        } else {
            System.out.println("El contacto no existe.");
        }
    }
    private static void eliminarContacto(String nombre, Map<String, List<String>> contactos, Scanner scanner) {
        if (contactos.containsKey(nombre)) {
            System.out.println("¿Esta usted seguro de que desea eliminar el contacto " + nombre + "? (s/n)");
            String confirmacion = scanner.nextLine().trim().toLowerCase();
            if (confirmacion.equals("s")) {
                contactos.remove(nombre);
                System.out.println("Contacto eliminado correctamente.");
            } else {
                System.out.println("Operacion cancelada.");
            }
        } else {
            System.out.println("El contacto no existe.");
        }
    }
    private static void mostrarContactos(Map<String, List<String>> contactos) {
        if (contactos.isEmpty()) {
            System.out.println("No hay contactos para mostrar.");
        } else {
            System.out.println("Lista de contactos: ");
            for (Map.Entry<String, List<String>> entry : contactos.entrySet()) {
                System.out.println(entry.getKey() + ": " + String.join(", ", entry.getValue()));
            }
        }
    }
}


