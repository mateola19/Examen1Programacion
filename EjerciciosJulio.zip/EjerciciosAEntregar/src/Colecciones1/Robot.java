package Colecciones1;

import java.time.LocalTime;
import java.util.*;

public class Robot {
	private String nombre;
    private int tiempoProceso;
    private LocalTime tiempoFinalProceso;
    public Robot(String nombre, int tiempoProceso) {
        this.nombre = nombre;
        this.tiempoProceso = tiempoProceso;
        this.tiempoFinalProceso = LocalTime.MIN;
    }
    public boolean estaDisponible(LocalTime tiempoActual) {
        return tiempoActual.isAfter(tiempoFinalProceso) || tiempoActual.equals(tiempoFinalProceso);
    }
    public void procesarProducto(String producto, LocalTime tiempoInicioProceso) {
        this.tiempoFinalProceso = tiempoInicioProceso.plusSeconds(tiempoProceso);
        System.out.println(nombre + " - " + producto + " [" + tiempoInicioProceso + "]");
        //System.out.println("Robot " + nombre + " está procesando " + producto + " desde las " + tiempoInicioProceso);
    }
}


