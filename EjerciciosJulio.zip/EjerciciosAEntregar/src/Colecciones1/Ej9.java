package Colecciones1;

import java.util.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Ej9 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese los robots y sus tiempos de proceso(nombreRobot-tiempoProceso): ");
        String[] robotsInfo = sc.nextLine().split(";");
        List<Robot> robots = new ArrayList<>();
        for (String robotInfo : robotsInfo) {
            String[] info = robotInfo.split("-");
            robots.add(new Robot(info[0], Integer.parseInt(info[1])));
        }
        System.out.println("Ingrese la hora de comienzo (hh:mm:ss): ");
        LocalTime horaComienzo = LocalTime.parse(sc.nextLine(), DateTimeFormatter.ofPattern("H:mm:ss"));
        System.out.println("Ingrese los productos: ");
        Queue<String> productos = new LinkedList<>();
        String producto;
        while (!(producto = sc.nextLine()).equals("fin")) {
            productos.offer(producto);
        }
        while (!productos.isEmpty()) {
            LocalTime tiempoActual = horaComienzo;
            String productoActual = productos.poll();
            for (Robot robot : robots) {
                if (robot.estaDisponible(tiempoActual)) {
                    robot.procesarProducto(productoActual, tiempoActual);
                    break;
                }
            }
            horaComienzo = horaComienzo.plusSeconds(1);
        }
        sc.close();
    }
}


