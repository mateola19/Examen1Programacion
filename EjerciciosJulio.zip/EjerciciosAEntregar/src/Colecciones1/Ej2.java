package Colecciones1;

import java.util.*;

public class Ej2 {
	public static void main(String[] args) {
        List<Integer> numerosAleatorios = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < 100; i++) {
            numerosAleatorios.add(random.nextInt(100) + 1);
        }
        System.out.println("Numeros aleatorios: ");
        for (int numeros : numerosAleatorios) {
            System.out.print(numeros + " ");
        }
        System.out.println();
        Set<Integer> conjuntoSinRepetidos = new HashSet<>(numerosAleatorios);
        System.out.println("\nNumeros sin repetir: ");
        Iterator<Integer> iterator = conjuntoSinRepetidos.iterator();
        while(iterator.hasNext()) {
        	System.out.print(iterator.next() + " ");
        }
        /*for (int numeros : conjuntoSinRepetidos) {
            System.out.print(numeros + " ");
        }*/
        System.out.println();
        Set<Integer> conjuntoOrdenadoSinRepetidos = new TreeSet<>(numerosAleatorios);
        System.out.println("\nNumeros ordenados y sin repetir:");
        conjuntoOrdenadoSinRepetidos.forEach(numero->System.out.print(numero  + " "));
        /*for (int numeros : conjuntoOrdenadoSinRepetidos) {
            System.out.print(numeros + " ");
        }*/
        System.out.println();
    }
}


