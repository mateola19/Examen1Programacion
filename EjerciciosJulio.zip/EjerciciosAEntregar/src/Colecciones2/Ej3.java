package Colecciones2;

import java.util.*;

public class Ej3 {
	public static void main(String[] args) {
        Map<String, String> mapa1 = Map.of("saber1", "valor3", "saber2", "valor2", "saber3", "valor1");
        Map<String, String> mapa2 = Map.of("saber1", "valor3", "saber5", "valor1", "saber4", "valor1");
        System.out.println("El mapa 1 tiene valores unicos: " + valoresUnicos(mapa1));
        System.out.println("El mapa 2 tiene valores unicos: " + valoresUnicos(mapa2));
    }
    public static boolean valoresUnicos(Map<String, String> mapa) {
        Set<String> valoresUnicos = new HashSet<>();
        for (Map.Entry<String, String> entry : mapa.entrySet()) {
            String valor = entry.getValue();
            if (valoresUnicos.contains(valor)) {
            	return false;
            } else {
                valoresUnicos.add(valor);
            }
        }
        return true;
    }
}


