package Colecciones2;

import java.util.*;

public class Ej8 {
	public static Map<String, Integer> interseccion(Map<String, Integer> mapa1, Map<String, Integer> mapa2) {
        Map<String, Integer> interseccionMap = new HashMap<>();
        for (Map.Entry<String, Integer> entry : mapa1.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            if (mapa2.containsKey(key) && mapa2.get(key).equals(value)) {
                interseccionMap.put(key, value);
            }
        }
        return interseccionMap;
    }
    public static void main(String[] args) {
        Map<String, Integer> mapa1 = new HashMap<>();
        mapa1.put("Fernando", 53);
        mapa1.put("Manuela", 29);
        mapa1.put("Ana", 41);
        mapa1.put("Luis", 65);
        mapa1.put("Mario", 33);
        mapa1.put("Adrian", 21);
        mapa1.put("Carmen", 39);
        mapa1.put("Elena", 19);

        Map<String, Integer> mapa2 = new HashMap<>();
        mapa2.put("Valentina", 37);
        mapa2.put("Ana", 41);
        mapa2.put("Mario", 33);
        mapa2.put("Benito", 67);
        mapa2.put("Carmen", 39);
        mapa2.put("Ramon", 44);
        mapa2.put("Elena", 19);
        mapa2.put("Hugo", 32);
        Map<String, Integer> interseccionMap = interseccion(mapa1, mapa2);
        System.out.println("Interseccion de los dos mapas: " + interseccionMap);
    }
}


