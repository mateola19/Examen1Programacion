package Colecciones2;

import java.util.*;

public class Ej13 {
	public static void main(String[] args) {
        Deque<Integer> pila1 = new LinkedList<>();
        pila1.push(5);
        pila1.push(11);
        pila1.push(-3);
        pila1.push(14);
        pila1.push(9);
        pila1.push(4);
        pila1.push(21);
        pila1.push(-42);
        pila1.push(13);
        pila1.push(2);
        System.out.println("Contenido inicial: " + pila1);
        colapsar(pila1);
        System.out.println("Contenido final: " + pila1);
        Deque<Integer> pila2 = new LinkedList<>();
        pila2.push(3);
        pila2.push(-5);
        pila2.push(7);
        pila2.push(-9);
        pila2.push(11);
        System.out.println("Contenido inicial: " + pila2);
        colapsar(pila2);
        System.out.println("Contenido final: " + pila2);
    }
	public static void colapsar(Deque<Integer> pila) {
        Deque<Integer> auxiliar = new LinkedList<>();
        boolean impar = false;
        if (pila.size() % 2 != 0) {
            impar = true;
        }
        while (!pila.isEmpty()) {
            int num1 = pila.pop();
            if (!pila.isEmpty()) {
                int num2 = pila.pop();
                auxiliar.push(num1 + num2);
            } else {
                if (impar) {
                    auxiliar.push(num1);
                }
            }
        }
        while (!auxiliar.isEmpty()) {
            pila.push(auxiliar.pop());
        }
    }
    
}


