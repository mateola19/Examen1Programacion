package Colecciones2;

import java.util.*;

public class Ej7 {
	 public static void main(String[] args) {
	        Stack<Integer> pila = new Stack<>();
	        pila.push(6);
	        pila.push(22);
	        pila.push(17);
	        pila.push(17);
	        pila.push(10);
	        pila.push(7);
	        pila.push(9);
	        pila.push(14);
	        pila.push(5);
	        pila.push(12);
	        pila.push(7);
	        pila.push(2);
	        System.out.println("Pila original: " + pila);
	        eliminarSiMayoresEncima(pila);
	        System.out.println("Pila modificada: " + pila);
	    }
	public static void eliminarSiMayoresEncima(Stack<Integer> pila) {
        Stack<Integer> auxiliar = new Stack<>();
        while (!pila.isEmpty()) {
            int current = pila.pop();
            /*while (!auxiliar.isEmpty() && auxiliar.peek() < current) {
                auxiliar.pop();
            }*/
            if(auxiliar.isEmpty() || auxiliar.peek()<=current) {
            	auxiliar.push(current);
            }
            
        }
        while (!auxiliar.isEmpty()) {
            pila.push(auxiliar.pop());
        }
    }
   
}


