package Colecciones2;

import java.util.*;

public class Ej1 {
	public static void main(String[] args) {
    	Set<String> conjunto = new HashSet<>();
    	conjunto.add("Hola");
    	conjunto.add("Comoos");
    	conjunto.add("Estas");
    	conjunto.add("Peritos");
    	System.out.println("Conjunto original: " + conjunto);
   	 	eliminarLasDeLongitudPar(conjunto);
    	System.out.println("Conjunto despues de eliminar las de longitud par: " + conjunto);
	}
	public static void eliminarLasDeLongitudPar(Set<String> conjunto) {
    	Iterator<String> iterator = conjunto.iterator();
    	while (iterator.hasNext()) {
        	String cadena = iterator.next();
        	if (cadena.length() % 2 == 0) {
            	iterator.remove();
        	}
    	}
	}
}


