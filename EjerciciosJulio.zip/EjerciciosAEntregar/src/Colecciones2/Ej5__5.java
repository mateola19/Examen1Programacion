package Colecciones2;

import java.util.*;

public class Ej5__5 {
	public static void main(String[] args) {
        Stack<Integer> pila = new Stack<>();
        pila.push(4);
        pila.push(53);
        pila.push(-8);
        pila.push(12);
        pila.push(532);
        pila.push(-63);
        pila.push(-44);
        System.out.println("Pila original: " + pila);
        negativosAbajoPositivosArriba(pila);
        System.out.println("Pila reorganizada: " + pila);
    }
    /*public static void negativosAbajoPositivosArriba(Stack<Integer> pila) {
        Queue<Integer> cola = new LinkedList<>();
        while (!pila.isEmpty()) {
            if (pila.peek() < 0) {
                cola.add(pila.pop());
            } else {
                break;
            }
        }
        while (!pila.isEmpty()) {
            if (pila.peek() >= 0) {
                cola.add(pila.pop());
            } else {
                break;
            }
        }
        while (!cola.isEmpty()) {
            pila.push(cola.remove());
        }
    }*/
	public static void negativosAbajoPositivosArriba(Stack<Integer> pila) {
        Deque<Integer> cola = new ArrayDeque<>();
        while (!pila.isEmpty()) {
            if (pila.peek() < 0) {
                cola.addFirst(pila.pop());
            } else {
                cola.addLast(pila.pop());
            }
        }

        while (!cola.isEmpty()) {
            pila.push(cola.remove());
        }
    }
}


