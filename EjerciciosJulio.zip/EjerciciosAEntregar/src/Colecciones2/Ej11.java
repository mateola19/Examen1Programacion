package Colecciones2;

import java.util.*;

public class Ej11 {
	public static void main(String[] args) {
        List<Integer> lista1 = List.of(7, 2, 44, 3);
        List<Integer> lista2 = List.of(7, 6, 4, 2);
        int comunes = contarComunes(lista1, lista2);
        System.out.println("Cantidad de numeros comunes: " + comunes);
    }
	public static int contarComunes(List<Integer> lista1, List<Integer> lista2) {
        Set<Integer> set1 = new HashSet<>(lista1);
        Set<Integer> set2 = new HashSet<>(lista2);
        int contador = 0;
        for (int num : set1) {
            if (set2.contains(num)) {
                contador++;
            }
        }
        return contador;
    }
    
}


