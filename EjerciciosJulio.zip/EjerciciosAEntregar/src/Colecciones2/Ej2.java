package Colecciones2;

import java.util.*;

public class Ej2 {
	public static void main(String[] args) {
        Set<Integer> conjunto1 = Set.of(2, 4, 6, 8);
        Set<Integer> conjunto2 = Set.of(4322, 14, 10, 5);
        System.out.println("El conjunto 1 contiene numeros impares: " + contieneImpares(conjunto1));
        System.out.println("El conjunto 2 contiene numeros impares: " + contieneImpares(conjunto2));
    }
    public static boolean contieneImpares(Set<Integer> conjunto) {
        for (Integer numero : conjunto) {
            if (numero % 2 != 0) {
                return true;
            }
        }
        return false;
    }
}


