package Colecciones2;

import java.util.*;

public class Ej10 {
	public static Map<String, Integer> cuentaPares(List<String> palabras) {
        Map<String, Integer> contarPares = new HashMap<>();
        for (String palabra : palabras) {
            if (palabra.length() < 2) {
                continue;
            }
            for (int i = 0; i < palabra.length() - 1; i++) {
                String par = palabra.substring(i, i + 2);
                contarPares.put(par, contarPares.getOrDefault(par, 0) + 1);
            }
        }
        return contarPares;
    }
    public static void main(String[] args) {
        List<String> palabras = List.of("banana", "pera", "melon", "o", "sandia");
        Map<String, Integer> conteoPares = cuentaPares(palabras);
        System.out.println("Conteo de pares:");
        for (Map.Entry<String, Integer> entry : conteoPares.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}


