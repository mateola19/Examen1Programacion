package Colecciones2;

import java.util.*;

public class Ej9 {
	public static int valorMenosRepetido(Map<String, Integer> mapa) {
        Map<Integer, Integer> contarEdades = new HashMap<>();
        int minimaRepeticion = Integer.MAX_VALUE;
        int valorMenosRepetido = Integer.MAX_VALUE;
        for (int edad : mapa.values()) {
            contarEdades.put(edad, contarEdades.getOrDefault(edad, 0) + 1);
        }
        for (Map.Entry<Integer, Integer> entry : contarEdades.entrySet()) {
            int edad = entry.getKey();
            int repeticiones = entry.getValue();
            if (repeticiones < minimaRepeticion || 
            		(repeticiones == minimaRepeticion && edad < valorMenosRepetido)) {
                minimaRepeticion = repeticiones;
                valorMenosRepetido = edad;
            }
        }
        return valorMenosRepetido;
    }
    public static void main(String[] args) {
        Map<String, Integer> edades = new HashMap<>();
        edades.put("Juan", 33);
        edades.put("Hugo", 29);
        edades.put("Ana", 45);
        edades.put("Luis", 47);
        edades.put("Mario", 33);
        edades.put("Rosa", 29);
        edades.put("Carmen", 33);
        edades.put("Elena", 59);
        edades.put("Benito", 33);
        int menosRepetido = valorMenosRepetido(edades);
        System.out.println("La edad que menos se repite es: " + menosRepetido);
    }
}


