package Colecciones2;

import java.util.*;

public class Ej4 {
	public static void main(String[] args) {
        List<String> lista1 = Arrays.asList("a", "b", "c", "a", "a", "b");
        List<String> lista2 = Arrays.asList("x", "y", "z", "x", "x", "x", "y");
        System.out.println("¿Algun elemento de la lista 1 se repite al menos 3 veces? " + 
        algunaSeRepiteAlMenos3Veces(lista1));
        System.out.println("¿Algun elemento de la lista 2 se repite al menos 3 veces? " + 
        algunaSeRepiteAlMenos3Veces(lista2));
    }
    public static boolean algunaSeRepiteAlMenos3Veces(List<String> lista) {
        Map<String, Integer> contador = new HashMap<>();
        for (String cadena : lista) {
            contador.put(cadena, contador.getOrDefault(cadena, 0) + 1);
        }
        for (int count : contador.values()) {
            if (count >= 3) {
                return true;
            }
        }
        return false;
    }
}


