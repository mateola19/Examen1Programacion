package Colecciones2;

import java.util.*;

public class Ej6 {
	public static void main(String[] args) {
        List<Integer> lista1 = Arrays.asList(9, 3, 1, 3, 9, 2, 9, 9, 3, 9);
        List<Integer> lista2 = Arrays.asList(7, 89, 0, 2, 98, 89, 1, 2, 3, 89);
        System.out.println("La moda de la lista 1 es: " + moda(lista1));
        System.out.println("La moda de la lista 2 es: " + moda(lista2));
    }
    public static int moda(List<Integer> lista) {
        if (lista.isEmpty()) {
            return 0;
        }
        Map<Integer, Integer> contador = new HashMap<>();
        for (int numero : lista) {
            contador.put(numero, contador.getOrDefault(numero, 0) + 1);
        }

        int moda = 0;
        int maxFrecuencia = 0;
        for (Map.Entry<Integer, Integer> entry : contador.entrySet()) {
            int frecuencia = entry.getValue();
            if (frecuencia > maxFrecuencia) {
                moda = entry.getKey();
                maxFrecuencia = frecuencia;
            }
        }
        return moda;
    }
}


